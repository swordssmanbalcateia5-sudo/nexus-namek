import {PROFILE_BODY_LIMIT} from './public/community-rules.js';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {dirname,resolve,sep,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {CommunityError,createCommunityStore} from './community-store.mjs';

const root=fileURLToPath(new URL('./public/',import.meta.url));
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.webp':'image/webp','.webmanifest':'application/manifest+json'};
function json(response,status,value){
  response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  response.end(JSON.stringify(value));
}
async function readBody(request,limit=8192){
  if(!request.headers['content-type']?.startsWith('application/json'))throw new CommunityError(415,'Envie JSON.');
  request.setEncoding('utf8');
  let content='';
  for await(const chunk of request){
    content+=chunk;
    if(Buffer.byteLength(content)>limit)throw new CommunityError(413,'Pedido muito grande.');
  }
  try{return JSON.parse(content);}
  catch{throw new CommunityError(400,'Pedido inválido.');}
}
export function createNexusServer(store){
  const registerLimits=new Map();
  async function api(request,response,pathname){
    const post=request.method==='POST';
    if(pathname==='/api/community/account'&&post){
      const ip=request.socket.remoteAddress;
      const now=Date.now();
      for(const [key,window] of registerLimits)if(window.until<=now)registerLimits.delete(key);
      const window=registerLimits.get(ip)??{count:0,until:now+3600000};
      if(window.count>=20)throw new CommunityError(429,'Limite temporário de criação de contas atingido.');
      const body=await readBody(request);
      const account=store.register(body?.name);
      window.count++;
      registerLimits.set(ip,window);
      return json(response,201,account);
    }
    const token=/^Bearer (\S+)$/.exec(request.headers.authorization??'')?.[1];
    const id=store.authenticate(token);
    if(request.method==='GET'){
      if(pathname==='/api/community/rankings')return json(response,200,store.rankings());
      if(pathname==='/api/community/friends')return json(response,200,store.friends(id));
      if(pathname==='/api/community/profile')return json(response,200,store.profile(id));
      const other=/^\/api\/community\/profile\/([a-f0-9-]{36})$/.exec(pathname)?.[1];
      if(other)return json(response,200,store.profile(other));
    }
    if(post){
      const body=await readBody(request,pathname==='/api/community/profile'?PROFILE_BODY_LIMIT:8192);
      if(pathname==='/api/game'){
        const result=store.sync(id,body?.action,body?.visible===true,body?.observationAge);
        const {seed,...visibleState}=result.state;
        return json(response,200,{...result,state:visibleState});
      }
      if(pathname==='/api/community/profile')return json(response,200,store.customize(id,body));
      if(pathname==='/api/community/friend-request'){store.requestFriend(id,body?.code);return json(response,200,{});}
      if(pathname==='/api/community/friend-reply'){store.replyFriend(id,body?.id,body?.decision);return json(response,200,{});}
      if(pathname==='/api/community/gift')return json(response,200,store.sendGift(id,body?.id));
    }
    throw new CommunityError(404,'Rota não encontrada.');
  }
  return createServer(async (request,response)=>{
    let pathname;
    try{pathname=decodeURIComponent(new URL(request.url,'http://localhost').pathname);}
    catch{response.writeHead(400).end();return;}
    if(pathname.startsWith('/api/')){
      try{await api(request,response,pathname);}
      catch(error){
        if(error instanceof CommunityError)json(response,error.status,{error:error.message});
        else{console.error(error);json(response,500,{error:'Não foi possível concluir o pedido.'});}
      }
      return;
    }
    try{
      const file=resolve(root,'.'+(pathname==='/'?'/index.html':pathname));
      if(!file.startsWith(root.endsWith(sep)?root:root+sep))throw new Error('fora da pasta pública');
      const contents=await readFile(file);
      response.writeHead(200,{'Content-Type':types[extname(file)]??'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      response.end(contents);
    }catch{response.writeHead(404);response.end('Arquivo não encontrado');}
  });
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const port=Number(process.env.PORT??4173);
  const host=process.env.NEXUS_HOST??'127.0.0.1';
  const dbPath=resolve(process.env.NEXUS_DB??'data/nexus.sqlite');
  await mkdir(dirname(dbPath),{recursive:true});
  const store=createCommunityStore(dbPath);
  const server=createNexusServer(store);
  server.listen(port,host,()=>console.log(`Nexus: http://${host}:${port}`));
  for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>server.close(()=>store.close()));
}
