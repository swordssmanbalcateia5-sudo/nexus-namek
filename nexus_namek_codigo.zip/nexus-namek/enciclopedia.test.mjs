import test from 'node:test';
import assert from 'node:assert/strict';
import {advance,advanceWithPresence,applyGameAction,canSellUnit,CHARACTERS,dexSummary,duplicateSellCandidates,fresh,makeBattle,SALE_PRICES,sellBatch,WORLDS} from './public/game.js';
import {packCampaign,unpackCampaign} from './public/save.js';
import {createCommunityStore} from './community-store.mjs';

test('enciclopédia hidrata saves legados e preserva descobertas mesmo após venda manual ou automática',()=>{
  const s=fresh(1000,31);
  // Save legado sem state.dex
  assert.equal(s.dex,undefined);
  s.collection.push({uid:'legacy-shiny',id:'zoro',xp:0,serial:1,shiny:true,trait:'Shunpo',odds:2000});
  const first=dexSummary(s);
  assert.equal(first.totals.seenChars,5);
  assert.equal(first.totals.shinyChars,1);
  assert.equal(first.totals.seenTraits,1);
  const zoroEntry=first.characters.find(c=>c.id==='zoro');
  assert.equal(zoroEntry.shiny,true);
  assert.deepEqual(zoroEntry.worlds,['Arlong Park']);

  // Vender a cópia preserva descoberta em state.dex
  assert.equal(applyGameAction(s,{type:'sell',uid:'legacy-shiny'},1000),true);
  const afterSell=dexSummary(s);
  assert.equal(afterSell.characters.find(c=>c.id==='zoro').shiny,true);
  assert.equal(afterSell.characters.find(c=>c.id==='zoro').count,0);
  assert.equal(afterSell.traits.find(t=>t.name==='Shunpo').seen,true);

  // Venda automática de novo recruta também registra na enciclopédia
  s.autoSell={enabled:true,tiers:[1],characters:[]};
  const b=makeBattle(s,s.clock+1);
  b.recruit={id:'yamcha',shiny:false,trait:null,odds:20};
  b.result.winner=0;b.result.reason='eliminação';b.result.events=[];
  s.pending=b;
  advance(s,b.end);
  assert.equal(dexSummary(s).characters.find(c=>c.id==='yamcha').normal,true);

  // Compatível com backup JSON (packCampaign / unpackCampaign)
  const restored=unpackCampaign(packCampaign(s),CHARACTERS,WORLDS);
  assert.deepEqual(restored.dex,s.dex);
});

test('trancar cópia bloqueia venda manual e em lote e pode ser destrancada',()=>{
  const s=fresh(1000,41);
  s.collection.push(
    {uid:'dup-1',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:20},
    {uid:'dup-2',id:'yamcha',xp:0,serial:3,shiny:false,trait:null,odds:20}
  );
  assert.equal(applyGameAction(s,{type:'lock',uid:'dup-1',locked:true},1000),true);
  assert.equal(applyGameAction(s,{type:'lock',uid:'dup-1',locked:true},1000),false);
  assert.equal(canSellUnit(s,'dup-1'),false);
  assert.equal(applyGameAction(s,{type:'sell',uid:'dup-1'},1000),false);
  assert.equal(sellBatch(s,['dup-1']),false);

  const cands=duplicateSellCandidates(s);
  assert.deepEqual(cands.map(u=>u.uid),['dup-2']);

  assert.equal(applyGameAction(s,{type:'lock',uid:'dup-1',locked:false},1000),true);
  assert.equal(canSellUnit(s,'dup-1'),true);
});

test('duplicateSellCandidates protege melhor cópia, equipe, trancadas, Shiny e traits raras; sellBatch preserva AFK',()=>{
  const s=fresh(1000,51);
  s.collection.push(
    {uid:'usopp-best',id:'usopp',xp:500,serial:1,shiny:false,trait:null,odds:20},
    {uid:'usopp-plain',id:'usopp',xp:0,serial:2,shiny:false,trait:null,odds:20},
    {uid:'usopp-shiny-1',id:'usopp',xp:0,serial:1,shiny:true,trait:null,odds:400},
    {uid:'usopp-shiny-2',id:'usopp',xp:0,serial:2,shiny:true,trait:null,odds:400}
  );
  // Sem cópia com trait superior, preserva usopp-best (maior XP) e protege Shinies
  assert.deepEqual(duplicateSellCandidates(s,{includeCommonTraits:false}).map(u=>u.uid),['usopp-plain']);

  // Adicionando cópias com trait comum e rara: a com Haki do Rei passa a ser a melhor normal
  s.collection.push(
    {uid:'usopp-common-trait',id:'usopp',xp:0,serial:3,shiny:false,trait:'Ten',odds:200},
    {uid:'usopp-rare-trait',id:'usopp',xp:0,serial:4,shiny:false,trait:'Haki do Rei',odds:1000}
  );
  assert.deepEqual(duplicateSellCandidates(s,{includeCommonTraits:false}).map(u=>u.uid).sort(),['usopp-best','usopp-plain']);
  const withCommon=duplicateSellCandidates(s,{includeCommonTraits:true});
  assert.deepEqual(withCommon.map(u=>u.uid).sort(),['usopp-best','usopp-common-trait','usopp-plain']);

  // Abre janela AFK e vende em lote + recruta depois para validar índices e recruitUids
  advanceWithPresence(s,1000,1000);
  const goldBefore=s.gold;
  const res=sellBatch(s,['usopp-plain','usopp-plain','usopp-common-trait','initial-piccolo']);
  assert.deepEqual(res,{sold:2,gold:2*SALE_PRICES[CHARACTERS.usopp.tier-1]});
  assert.equal(s.gold,goldBefore+res.gold);

  const b=makeBattle(s,1000+11*60000);
  b.recruit={id:'nami',shiny:false,trait:null,odds:40};
  b.result.winner=0;b.result.reason='eliminação';b.result.events=[];
  s.pending=b;s.clock=b.start;
  advanceWithPresence(s,b.end,b.end);
  assert.equal(s.awayReports.length,1);
  assert.equal(s.awayReports[0].recruitUids.length,1);
  assert.equal(s.awayReports[0].lastRecruit-s.awayReports[0].firstRecruit,1);

  // Limite de 200 por lote e proteção contra esvaziar coleção
  assert.equal(sellBatch(s,Array.from({length:201},(_,i)=>'x-'+i)),false);
});

test('servidor online aceita lock e sellBatch com validação autoritativa',()=>{
  const store=createCommunityStore(':memory:',{now:()=>10000});
  try{
    const {player}=store.register('Colecionador');
    const first=store.sync(player.id,{type:'lock',uid:'initial-piccolo',locked:true},true,0);
    assert.equal(first.changed,true);
    assert.equal(first.state.collection.find(u=>u.uid==='initial-piccolo').locked,true);
    const blocked=store.sync(player.id,{type:'sellBatch',uids:['initial-piccolo']},true,0);
    assert.equal(blocked.changed,false);
  }finally{store.close();}
});
