import {serialSchema,issueSerials} from '../serials.mjs';
import {advance,advanceWithPresence,applyGameAction,fighter,fresh,CHARACTERS} from '../public/game.js';
import {dailyCycle,DEFAULT_PROFILE,appearancePatch,PROFILE_BODY_LIMIT,GIFT_GOLD} from '../public/community-rules.js';

class ApiError extends Error {
  constructor(status,message){super(message);this.status=status;}
}
function reject(status,message){throw new ApiError(status,message);}
const schemas=[
  `CREATE TABLE IF NOT EXISTS nexus_players(
    id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, token_hash TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL, game TEXT NOT NULL, appearance TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 0, play_ms INTEGER NOT NULL DEFAULT 0, last_seen INTEGER,
    reg_key TEXT NOT NULL, power INTEGER NOT NULL, top_units TEXT NOT NULL, rare_units TEXT NOT NULL)`,
  'CREATE INDEX IF NOT EXISTS nexus_registration ON nexus_players(reg_key)',
  'CREATE INDEX IF NOT EXISTS nexus_power ON nexus_players(power DESC,name,id)',
  `CREATE TABLE IF NOT EXISTS nexus_friends(
    a TEXT NOT NULL REFERENCES nexus_players(id), b TEXT NOT NULL REFERENCES nexus_players(id),
    requested_by TEXT NOT NULL REFERENCES nexus_players(id), accepted INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(a,b),CHECK(a<b))`,
  'CREATE INDEX IF NOT EXISTS nexus_friends_b ON nexus_friends(b)',
  `CREATE TABLE IF NOT EXISTS nexus_gifts(
    sender TEXT NOT NULL REFERENCES nexus_players(id), recipient TEXT NOT NULL REFERENCES nexus_players(id),
    day TEXT NOT NULL, gold INTEGER NOT NULL, sent_at INTEGER NOT NULL,PRIMARY KEY(sender,recipient,day))`,
  'CREATE INDEX IF NOT EXISTS nexus_inbox ON nexus_gifts(recipient,sent_at DESC)',
  `CREATE TRIGGER IF NOT EXISTS nexus_gift_credit AFTER INSERT ON nexus_gifts BEGIN
    UPDATE nexus_players SET game=json_set(game,'$.gold',json_extract(game,'$.gold')+NEW.gold),
      revision=revision+1 WHERE id=NEW.recipient;
  END`
];
const initialized=new WeakSet();
async function initialize(db){
  if(initialized.has(db))return;
  await db.batch([...schemas,...serialSchema('nexus_players',true)].map(sql=>db.prepare(sql)));
  initialized.add(db);
}
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
const random=count=>crypto.getRandomValues(new Uint8Array(count));
const hash=async value=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));
const publicPlayer=({id,name,code})=>({id,name,code});
function summarize(unit){
  const stats=fighter(unit);
  const power=['hp','attack','magic','defense','resistance','speed'].reduce((sum,k)=>sum+stats[k],0);
  return {id:unit.id,xp:unit.xp,name:CHARACTERS[unit.id].name,level:stats.level,shiny:unit.shiny,
    trait:unit.trait,stars:stats.stars,nen:unit.nen===true,serial:unit.serial,odds:unit.odds,power};
}
function rankedUnits(collection){
  const units=collection.map(summarize);
  const rarity=(a,b)=>(b.odds??0)-(a.odds??0)||a.name.localeCompare(b.name)||a.serial-b.serial;
  const rare=units.filter(u=>u.odds>0).sort(rarity).slice(0,30);
  const top=units.sort((a,b)=>b.power-a.power||rarity(a,b)).slice(0,4);
  return [top.reduce((sum,u)=>sum+u.power,0),JSON.stringify(top),JSON.stringify(rare)];
}
async function register(db,input,request){
  const name=typeof input.name==='string'?input.name.normalize('NFC').trim().replace(/\s+/gu,' '):'';
  if(!/^[\p{L}\p{N} _.-]{2,24}$/u.test(name))reject(400,'Use de 2 a 24 letras ou números no nome.');
  const now=Date.now();
  const regKey=await hash(Math.floor(now/3600000)+'/'+(request.headers.get('CF-Connecting-IP')??'local'));
  const token=btoa(String.fromCharCode(...random(24))).replaceAll('+','-').replaceAll('/','_');
  const state=fresh(now,crypto.getRandomValues(new Uint32Array(1))[0]);
  const tokenHash=await hash(token);
  const id=crypto.randomUUID();
  for(let attempt=0;attempt<3;attempt++){
    const counter=await db.prepare('SELECT * FROM nexus_serials WHERE id=1').first();
    issueSerials(state,state.collection,counter);
    const ranks=rankedUnits(state.collection);
    const code=hex(random(5)).toUpperCase();
    const inserted=await db.prepare(`INSERT INTO nexus_players(id,code,token_hash,name,game,appearance,reg_key,power,top_units,rare_units)
      SELECT ?,?,?,?,?,?,?,?,?,? WHERE (SELECT revision FROM nexus_serials WHERE id=1)=? AND (SELECT count(*) FROM nexus_players WHERE reg_key=?)<20
      ON CONFLICT(code) DO NOTHING RETURNING id`).bind(id,code,tokenHash,name,JSON.stringify(state),JSON.stringify(DEFAULT_PROFILE),regKey,...ranks,counter.revision,regKey).first();
    if(inserted)return {token,player:{id,name,code}};
    const count=await db.prepare('SELECT count(*) AS n FROM nexus_players WHERE reg_key=?').bind(regKey).first();
    if(count.n>=20)reject(429,'Limite temporário de criação de contas atingido.');
  }
  reject(503,'Tente criar o perfil novamente.');
}
async function authenticate(db,request){
  const token=/^Bearer ([A-Za-z0-9_-]{32})$/.exec(request.headers.get('Authorization')??'')?.[1];
  if(!token)reject(401,'Entre na sua conta da comunidade.');
  const row=await db.prepare('SELECT id FROM nexus_players WHERE token_hash=?').bind(await hash(token)).first();
  if(!row)reject(401,'Código de acesso inválido.');
  return row.id;
}
async function sync(db,id,body){
  // A concurrent sync or gift changes the revision. Recalculate from the newest checkpoint.
  for(let attempt=0;attempt<4;attempt++){
    const row=await db.prepare('SELECT id,name,code,game,revision,last_seen FROM nexus_players WHERE id=?').bind(id).first();
    const state=JSON.parse(row.game),now=Date.now(),previous=state.pending;
    const age=body.observationAge===undefined&&body.visible===true?0:body.observationAge;
    const seen=Number.isFinite(age)&&age>=0?now-age:null;
    const entries=advanceWithPresence(state,now,seen);
    const last=entries.at(-1);
    const finished=previous&&last?.end===previous.end?{battle:previous,entry:last}:null;
    const changed=applyGameAction(state,body.action,now);
    if(changed)entries.push(...advance(state,now));
    const units=entries.map(e=>e.recruit||e.sold).filter(Boolean);
    const counter=units.length?await db.prepare('SELECT * FROM nexus_serials WHERE id=1').first():null;
    issueSerials(state,units,counter);
    const delta=now-(row.last_seen??now);
    const played=delta>0&&delta<=20000?delta:0;
    const ranks=rankedUnits(state.collection);
    const result=await db.prepare(`UPDATE nexus_players SET game=?,play_ms=play_ms+?,last_seen=?,
      power=?,top_units=?,rare_units=?,revision=revision+1 WHERE id=? AND revision=? AND (? IS NULL OR (SELECT revision FROM nexus_serials WHERE id=1)=?)`)
      .bind(JSON.stringify(state),played,body.visible===true?now:null,...ranks,id,row.revision,counter?.revision??null,counter?.revision??null).run();
    if(!result.meta.changes)continue;
    delete state.seed;
    return {state,changed,finished,now,player:publicPlayer(row),entries:entries.slice(-25),
      offline:{total:entries.length,wins:entries.filter(e=>e.won).length,gold:entries.reduce((sum,e)=>sum+e.gold,0),recruits:entries.filter(e=>e.recruit).length}};
  }
  reject(409,'A campanha está sendo atualizada. Tente novamente.');
}
async function profile(db,id){
  const row=await db.prepare('SELECT id,name,code,game,appearance,play_ms,rare_units FROM nexus_players WHERE id=?').bind(id).first();
  if(!row)reject(404,'Jogador não encontrado.');
  const state=JSON.parse(row.game);
  return {...publicPlayer(row),appearance:JSON.parse(row.appearance),playMs:row.play_ms,encounters:state.wins+state.losses,
    leaderId:state.collection.find(u=>u.uid===state.leader)?.id,team:state.team.map(uid=>summarize(state.collection.find(u=>u.uid===uid))),
    showcase:JSON.parse(row.rare_units).slice(0,5)};
}
async function rankings(db){
  const [power,rarity]=await db.batch([
    db.prepare('SELECT id,name,power,top_units FROM nexus_players ORDER BY power DESC,name,id LIMIT 30'),
    db.prepare(`SELECT p.id,p.name,u.value AS unit FROM nexus_players p,json_each(p.rare_units) u
      ORDER BY json_extract(u.value,'$.odds') DESC,json_extract(u.value,'$.name'),json_extract(u.value,'$.serial'),p.id LIMIT 30`)
  ]);
  return {power:power.results.map(({id,name,power,top_units})=>({player:{id,name},power,units:JSON.parse(top_units)})),
    rarity:rarity.results.map(({id,name,unit})=>({...JSON.parse(unit),player:{id,name}}))};
}
const pair=(a,b)=>a<b?[a,b]:[b,a];
async function friends(db,id){
  const now=Date.now(),cycle=dailyCycle(now);
  const [connections,inbox]=await db.batch([
    db.prepare(`SELECT p.id,p.name,p.code,f.accepted,f.requested_by,
      EXISTS(SELECT 1 FROM nexus_gifts g WHERE g.sender=? AND g.recipient=p.id AND g.day=?) AS sent
      FROM nexus_friends f JOIN nexus_players p ON p.id=CASE WHEN f.a=? THEN f.b ELSE f.a END
      WHERE f.a=? OR f.b=? ORDER BY p.name,p.id`).bind(id,cycle.day,id,id,id),
    db.prepare(`SELECT p.id,p.name,g.gold,g.sent_at AS sentAt FROM nexus_gifts g JOIN nexus_players p ON p.id=g.sender
      WHERE g.recipient=? ORDER BY g.sent_at DESC LIMIT 20`).bind(id)
  ]);
  return {friends:connections.results.filter(r=>r.accepted),requests:connections.results.filter(r=>!r.accepted),inbox:inbox.results,cycle,now,giftGold:GIFT_GOLD};
}
async function invite(db,id,code){
  if(typeof code!=='string'||!/^[a-f0-9]{10}$/i.test(code.trim()))reject(400,'Informe o código de amigo com 10 caracteres.');
  const other=await db.prepare('SELECT id FROM nexus_players WHERE code=?').bind(code.trim().toUpperCase()).first();
  if(!other)reject(404,'Código de amigo não encontrado.');
  if(other.id===id)reject(400,'Esse é o seu próprio código.');
  const result=await db.prepare(`INSERT OR IGNORE INTO nexus_friends(a,b,requested_by) SELECT ?,?,?
    WHERE (SELECT count(*) FROM nexus_friends WHERE a=? OR b=?)<40 AND (SELECT count(*) FROM nexus_friends WHERE a=? OR b=?)<40`)
    .bind(...pair(id,other.id),id,id,id,other.id,other.id).run();
  if(!result.meta.changes)reject(409,'Já existe um convite ou o limite de amigos foi atingido.');
}
async function reply(db,id,body){
  if(typeof body.id!=='string'||!['accept','remove'].includes(body.decision))reject(400,'Resposta inválida.');
  const ids=pair(id,body.id);
  const statement=body.decision==='remove'
    ?db.prepare('DELETE FROM nexus_friends WHERE a=? AND b=?').bind(...ids)
    :db.prepare('UPDATE nexus_friends SET accepted=1 WHERE a=? AND b=? AND requested_by<>? AND accepted=0').bind(...ids,id);
  if(!(await statement.run()).meta.changes)reject(409,'A amizade ou o convite já mudou.');
}
async function gift(db,id,recipient){
  if(typeof recipient!=='string')reject(400,'Escolha um amigo.');
  const now=Date.now(),ids=pair(id,recipient);
  const result=await db.prepare(`INSERT OR IGNORE INTO nexus_gifts(sender,recipient,day,gold,sent_at)
    SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM nexus_friends WHERE a=? AND b=? AND accepted=1)`)
    .bind(id,recipient,dailyCycle(now).day,GIFT_GOLD,now,...ids).run();
  if(!result.meta.changes){
    if(!await db.prepare('SELECT 1 FROM nexus_friends WHERE a=? AND b=? AND accepted=1').bind(...ids).first())reject(403,'Presentes são exclusivos para amigos confirmados.');
    reject(409,'Você já enviou um presente a esse amigo neste ciclo.');
  }
  return {gold:GIFT_GOLD};
}
async function readBody(request,limit=8192){
  if(!request.headers.get('Content-Type')?.startsWith('application/json'))reject(415,'Envie JSON.');
  const reader=request.body?.getReader();
  if(!reader)reject(400,'Pedido inválido.');
  const decoder=new TextDecoder();let raw='',bytes=0;
  for(;;){
    const chunk=await reader.read();if(chunk.done)break;
    bytes+=chunk.value.byteLength;
    if(bytes>limit){await reader.cancel();reject(413,'Pedido muito grande.');}
    raw+=decoder.decode(chunk.value,{stream:true});
  }
  let body;
  try{body=JSON.parse(raw+decoder.decode());}catch{reject(400,'Pedido inválido.');}
  if(!body||Array.isArray(body)||typeof body!=='object')reject(400,'Pedido inválido.');
  return body;
}
function json(value,status=200){
  return Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
export default {
  async fetch(request,env){
    const path=new URL(request.url).pathname;
    if(!path.startsWith('/api/'))return env.ASSETS.fetch(request);
    try{
      const db=env.NEXUS_DB;
      if(!db)reject(503,'Vincule o banco D1 como NEXUS_DB neste ambiente do Pages e publique a versão novamente.');
      await initialize(db);
      const post=request.method==='POST';
      
      if(post&&path==='/api/community/account')return json(await register(db,await readBody(request),request),201);
      const id=await authenticate(db,request);
      const body=post?await readBody(request,path==='/api/community/profile'?PROFILE_BODY_LIMIT:8192):null;
      if(request.method==='GET'){
        if(path==='/api/community/profile')return json(await profile(db,id));
        const other=/^\/api\/community\/profile\/([a-f0-9-]{36})$/.exec(path)?.[1];
        if(other)return json(await profile(db,other));
        if(path==='/api/community/friends')return json(await friends(db,id));
        if(path==='/api/community/rankings')return json(await rankings(db));
      }
      if(post){
        if(path==='/api/game')return json(await sync(db,id,body));
        if(path==='/api/community/profile'){
          let patch;
          try{patch=appearancePatch(body);}catch(error){reject(400,error.message);}
          await db.prepare('UPDATE nexus_players SET appearance=json_patch(appearance,?) WHERE id=?').bind(JSON.stringify(patch),id).run();
          return json(await profile(db,id));
        }
        if(path==='/api/community/friend-request'){await invite(db,id,body.code);return json({});}
        if(path==='/api/community/friend-reply'){await reply(db,id,body);return json({});}
        if(path==='/api/community/gift')return json(await gift(db,id,body.id));
      }
      reject(404,'Rota não encontrada.');
    }catch(error){
      if(error instanceof ApiError)return json({error:error.message},error.status);
      console.error('Nexus API:',error.message);
      return json({error:'Falha ao acessar a Comunidade. Confira o banco D1 nos registros do Pages.'},500);
    }
  }
};
