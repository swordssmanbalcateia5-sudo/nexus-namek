import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import worker from '../public/_worker.js';

// Execute the packaged handler and its SQL through the same D1 binding interface.
function binding(sqlite){
  function prepare(sql,values=[]){
    return {
      bind:(...args)=>prepare(sql,args),
      first:async()=>sqlite.prepare(sql).get(...values)??null,
      run:async()=>({meta:{changes:sqlite.prepare(sql).run(...values).changes}}),
      all:async()=>({results:sqlite.prepare(sql).all(...values)})
    };
  }
  return {prepare,async batch(statements){
    sqlite.exec('BEGIN');try{
      const rows=[];for(const stmt of statements)rows.push(await stmt.all());
      sqlite.exec('COMMIT');return rows;
    }catch(error){sqlite.exec('ROLLBACK');throw error;}
  }};
}
test('deploy gerado cria duas contas, persiste sessão e campanha e transmite amizade, presente e ranking',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'nexus-pages-')),path=join(dir,'test.sqlite');
  let sqlite=new DatabaseSync(path);
  const env={NEXUS_DB:binding(sqlite),ASSETS:{fetch:()=>new Response('Nexus')}};
  async function api(path,token,body,status=200){
    const headers=token?{Authorization:'Bearer '+token}:{};
    if(body!==undefined)headers['Content-Type']='application/json';
    const response=await worker.fetch(new Request('https://nexus.test/api/'+path,{method:body===undefined?'GET':'POST',headers,body:JSON.stringify(body)}),env);
    const data=await response.json();assert.equal(response.status,status,JSON.stringify(data));return data;
  }
  try{
    assert.equal(await (await worker.fetch(new Request('https://nexus.test/'),env)).text(),'Nexus');
    assert.equal((await worker.fetch(new Request('https://nexus.test/api/game'),{})).status,503);
    await api('community/account',null,{name:'?'},400);
    const a=await api('community/account',null,{name:'Sword'},201),b=await api('community/account',null,{name:'Mira'},201);
    assert.equal(a.token.length,32);
    await api('community/profile',a.player.code,undefined,401);
    const login=await api('game',a.token,{visible:true});
    assert.equal(login.state.collection[0].serial,1);
    assert.equal((await api('game',b.token,{visible:true})).state.collection[0].serial,2);
    assert.equal(login.player.name,'Sword');assert.equal(login.state.collection.length,4);assert(!('seed' in login.state));
    await api('game',a.token,{action:{type:'saleSetting',group:'enabled',checked:true}});
    await api('community/profile',a.token,{background:'aurora',icon:'cometa',border:'ouro'});
    const avatar='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAABUUlEQVR4nO3SMQHAIADAsDErGEcF9kAGRxMFPTrW3Ocj638dwFsGiDNAnAHiDBBngDgDxBkgzgBxBogzQJwB4gwQZ4A4A8QZIM4AcQaIM0CcAeIMEGeAOAPEGSDOAHEGiDNAnAHiDBBngDgDxBkgzgBxBogzQJwB4gwQZ4A4A8QZIM4AcQaIM0CcAeIMEGeAOAPEGSDOAHEGiDNAnAHiDBBngDgDxBkgzgBxBogzQJwB4gwQZ4A4A8QZIM4AcQaIM0CcAeIMEGeAOAPEGSDOAHEGiDNAnAHiDBBngDgDxBkgzgBxBogzQJwB4gwQZ4A4A8QZIM4AcQaIM0CcAeIMEGeAOAPEGSDOAHEGiDNAnAHiDBBngDgDxBkgzgBxBogzQJwB4gwQZ4A4A8QZIM4AcQaIM0CcAeIMEGeAOAPEGSDOAHEGiDNAnAHiDBBngDgDxF2iIgN4XmdwEgAAAABJRU5ErkJggg==';
    const style={background:'shibuya',icon:'cometa',border:'ouro'};
    await api('community/profile',a.token,{...style,avatar});
    assert.equal((await api('community/profile/'+a.player.id,b.token)).appearance.avatar,avatar);
    await api('community/profile',a.token,{...style,background:'morioh'});
    await api('community/profile',a.token,{...style,avatar:'invalid'},400);
    await api('community/profile',null,{...style,avatar:null},401);
    sqlite.close();sqlite=new DatabaseSync(path);env.NEXUS_DB=binding(sqlite);
    assert.equal((await api('game',a.token,{visible:true})).state.autoSell.enabled,true);
    assert.equal((await api('community/profile',a.token)).appearance.icon,'cometa');
    const restored=(await api('community/profile',a.token)).appearance;
    assert.equal(restored.background,'morioh');assert.equal(restored.avatar,avatar);
    await api('community/profile',a.token,{...style,avatar:null});
    assert.equal((await api('community/profile/'+a.player.id,b.token)).appearance.avatar,undefined);
    await api('community/gift',a.token,{id:b.player.id},403);
    await api('community/friend-request',a.token,{code:b.player.code});
    assert.equal((await api('community/friends',b.token)).requests.length,1);
    await api('community/friend-reply',a.token,{id:b.player.id,decision:'accept'},409);
    await api('community/friend-reply',b.token,{id:a.player.id,decision:'accept'});
    const before=(await api('game',b.token,{visible:true})).state.gold;
    await Promise.all([api('community/gift',a.token,{id:b.player.id}),api('game',b.token,{visible:true})]);
    await api('community/gift',a.token,{id:b.player.id},409);
    assert.equal((await api('game',b.token,{visible:true})).state.gold,before+10);
    assert.equal((await api('community/friends',b.token)).inbox.length,1);
    const ranking=await api('community/rankings',a.token);
    assert.equal(ranking.power.length,2);
    assert.equal((await api('community/profile/'+b.player.id,a.token)).name,'Mira');
    assert(!JSON.stringify(ranking).includes(a.token));
    await api('community/friend-reply',b.token,{id:a.player.id,decision:'remove'});
    assert.equal((await api('community/friends',a.token)).friends.length,0);
  }finally{sqlite.close();rmSync(dir,{recursive:true,force:true});}
});
