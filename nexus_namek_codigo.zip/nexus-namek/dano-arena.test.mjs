import test from 'node:test';
import assert from 'node:assert/strict';
import {createDuel,stepDuel,collisionPower} from './public/duel.js';

const unit=(name,extra={})=>({name,hp:20000,attack:100,magic:80,defense:0,resistance:0,speed:100,kind:'beam',role:'Mágico',...extra});
test('painel prevê o próximo impacto com magia, trait, bônus individual e teto',()=>{
  const m=createDuel([unit('Luz',{trait:'Made in Heaven',magicBasic:true})],[unit('Alvo')]);
  const f=m.sides[0].team[0];
  for(const [hits,power] of [[0,320],[1,358.4],[4,448],[8,448]]){
    f.hits=hits;assert.ok(Math.abs(collisionPower(m,f)-power)<.000001);
  }
  f.weakenUntil=1000;assert.ok(Math.abs(collisionPower(m,f)-448*.65)<.000001);
});
test('eventos da Arena identificam atacante, reserva, alvo e PV efetivamente removidos',()=>{
  const m=createDuel([unit('Titular'),unit('Reserva')],[unit('Rival')]);
  const seen=[];
  for(let i=0;i<420;i++){
    const prev=m.combat.log.length;stepDuel(m);
    for(const row of m.damageFeed.filter(h=>h.seq>=prev)){
      const event=m.combat.log[row.seq];
      assert.equal(event.hp,row.amount);assert.ok(row.amount>0);
      seen.push(row);
    }
  }
  assert.ok(seen.some(r=>r.side===0&&r.source==='Reserva'&&r.target==='Rival'));
  assert.ok(seen.some(r=>r.side===1&&r.source==='Rival'));
});
