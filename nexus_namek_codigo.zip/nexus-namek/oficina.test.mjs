import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {advanceWithPresence,applyGameAction,awakenCost,awakenUnit,CHARACTERS,fighter,fresh,makeBattle,MAX_STARS,resolveTrait,rollTrait,traitRollCost,WORLDS} from './public/game.js';
import {packCampaign,unpackCampaign} from './public/save.js';
import {createCommunityStore} from './community-store.mjs';
import worker from './public/_worker.js';

test('despertar consome duplicata reserva, soma +4% por estrela até ★5 sem mudar velocidade e preserva AFK',()=>{
  const s=fresh(1000,61);
  const base=fighter(s.collection[0]);
  s.collection.push({uid:'pic-dup-1',id:'piccolo',xp:0,serial:2,shiny:false,trait:null,odds:50});
  s.collection.push({uid:'yam-dup',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:20});
  // Rejeita personagem diferente, titular como material ou sem ouro
  assert.equal(awakenUnit(s,'initial-piccolo','yam-dup'),false);
  assert.equal(awakenUnit(s,'initial-piccolo','initial-piccolo'),false);
  assert.equal(awakenUnit(s,'pic-dup-1','initial-piccolo'),false);
  s.gold=0;
  assert.equal(awakenUnit(s,'initial-piccolo','pic-dup-1'),false);

  // Abre janela AFK para garantir que consumir material não apaga recrutas futuros
  advanceWithPresence(s,1000,1000);
  const cost1=awakenCost(s.collection[0]);
  s.gold=cost1;
  assert.equal(awakenUnit(s,'initial-piccolo','pic-dup-1'),1);
  assert.equal(s.gold,0);
  assert.equal(s.collection.some(u=>u.uid==='pic-dup-1'),false);

  const star1=fighter(s.collection[0]);
  assert.equal(star1.stars,1);
  assert.ok(star1.hp>base.hp&&star1.attack>base.attack);
  assert.equal(star1.speed,base.speed);

  // Recruta durante AFK após despertar deve aparecer no relatório
  const b=makeBattle(s,1000+11*60000);
  b.recruit={id:'kuririn',shiny:false,trait:null,odds:40};
  b.result.winner=0;b.result.reason='eliminação';b.result.events=[];
  s.pending=b;s.clock=b.start;
  advanceWithPresence(s,b.end,b.end);
  assert.equal(s.awayReports[0].recruitUids.length,1);
  assert.equal(s.awayReports[0].lastRecruit-s.awayReports[0].firstRecruit,1);

  // Teto ★5
  s.collection[0].stars=MAX_STARS;
  assert.equal(awakenCost(s.collection[0]),null);
  s.collection.push({uid:'pic-dup-6',id:'piccolo',xp:0,serial:3,shiny:false,trait:null,odds:50});
  s.gold=1e7;
  assert.equal(awakenUnit(s,'initial-piccolo','pic-dup-6'),false);
});

test('oficina de traits permite manter ou aplicar, preserva odds e limpa Voto de Nen ao trocar',()=>{
  const s=fresh(1000,73);
  const u=s.collection[0];
  u.odds=123456;
  u.trait='Voto de Nen';
  u.nen=true;
  const cost=traitRollCost(u);
  s.gold=cost-1;
  assert.equal(rollTrait(s,u.uid),false);

  s.gold=cost*2;
  const first=rollTrait(s,u.uid);
  assert.ok(first&&typeof first.candidate==='string');
  assert.equal(s.gold,cost);
  // Bloqueia segunda rolagem enquanto há pendente
  assert.equal(rollTrait(s,u.uid),false);

  // Manter preserva trait e nen
  assert.equal(resolveTrait(s,true),true);
  assert.equal(u.trait,'Voto de Nen');
  assert.equal(u.nen,true);
  assert.equal(s.pendingTrait,undefined);

  // Segunda rolagem e aplicar nova trait (não-Voto de Nen) deve limpar u.nen e manter odds original
  let next=rollTrait(s,u.uid);
  assert.ok(next);
  if(next.candidate==='Voto de Nen')next.candidate='Ten';
  assert.equal(applyGameAction(s,{type:'resolveTrait',keep:false},1000),true);
  assert.equal(u.trait,next.candidate);
  assert.equal(u.nen,undefined);
  assert.equal(u.odds,123456);

  const restored=unpackCampaign(packCampaign(s),CHARACTERS,WORLDS);
  assert.equal(restored.collection[0].trait,u.trait);
});

test('estrelas e oficina sincronizam no servidor Node e no Worker do Cloudflare D1',async()=>{
  // Node SQLite
  const store=createCommunityStore(':memory:',{now:()=>9000});
  try{
    const a=store.register('Ferreiro');
    const beforePower=store.rankings().power[0].power;
    // Sem ouro suficiente falha
    assert.equal(store.sync(a.player.id,{type:'rollTrait',uid:'initial-piccolo'},true,0).changed,false);
    assert.ok(beforePower>0);
  }finally{store.close();}

  // Cloudflare Worker D1
  const sqlite=new DatabaseSync(':memory:');
  function binding(db){
    function prepare(sql,values=[]){
      return {
        bind:(...args)=>prepare(sql,args),
        first:async()=>db.prepare(sql).get(...values)??null,
        run:async()=>({meta:{changes:db.prepare(sql).run(...values).changes}}),
        all:async()=>({results:db.prepare(sql).all(...values)})
      };
    }
    return {prepare,async batch(stmts){
      db.exec('BEGIN');try{
        const rows=[];for(const st of stmts)rows.push(await st.all());
        db.exec('COMMIT');return rows;
      }catch(e){db.exec('ROLLBACK');throw e;}
    }};
  }
  const env={NEXUS_DB:binding(sqlite),ASSETS:{fetch:()=>new Response('ok')}};
  async function api(path,token,body){
    const headers=token?{Authorization:'Bearer '+token}:{};
    if(body!==undefined)headers['Content-Type']='application/json';
    const res=await worker.fetch(new Request('https://nexus.test/api/'+path,{method:body===undefined?'GET':'POST',headers,body:JSON.stringify(body)}),env);
    return res.json();
  }
  const p=await api('community/account',null,{name:'Mestre'});
  const raw=sqlite.prepare('SELECT game FROM nexus_players WHERE id=?').get(p.player.id);
  const st=JSON.parse(raw.game);
  st.gold=100000;
  st.collection.push({uid:'dup-pic',id:'piccolo',xp:0,serial:99,shiny:false,trait:null,odds:50});
  sqlite.prepare('UPDATE nexus_players SET game=? WHERE id=?').run(JSON.stringify(st),p.player.id);

  const beforeRank=await api('community/rankings',p.token);
  const awakened=await api('game',p.token,{action:{type:'awaken',uid:'initial-piccolo',materialUid:'dup-pic'},visible:true});
  assert.equal(awakened.changed,true);
  assert.equal(awakened.state.collection[0].stars,1);
  const afterRank=await api('community/rankings',p.token);
  assert.ok(afterRank.power[0].power>beforeRank.power[0].power);
  const prof=await api('community/profile',p.token);
  assert.equal(prof.team[0].stars,1);
  sqlite.close();
});
