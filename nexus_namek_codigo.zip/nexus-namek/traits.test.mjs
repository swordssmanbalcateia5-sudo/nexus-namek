import test from 'node:test';
import assert from 'node:assert/strict';
import {Combate,affinity} from './public/engine.js';
import {TRAITS,CHARACTERS,fighter,fresh,applyGameAction,formationCost} from './public/game.js';
const unit=(trait=null)=>({trait,hp:10000,attack:100,magic:100,interval:2000});
test('Made in Heaven: 4× permanente, aceleração de cinco segundos sem acumular e apenas uma ativação',()=>{
  const c=new Combate([[unit('Made in Heaven'),unit('Made in Heaven'),unit()],[unit()]],{mode:'equipe'});
  const [a,b,ally]=c.teams[0],foe=c.active(1);
  c.time=1000;c.hit(a,foe);assert.equal(foe.hp,9600);
  assert.equal(c.pace(a),.2);assert.equal(c.pace(ally),.6);
  c.hit(b,foe);assert.equal(c.pace(ally),.6);
  c.time=6000;c.hit(a,foe);assert.equal(c.pace(a),1);assert.equal(foe.hp,8800);
  assert.equal(c.log.filter(e=>e.type==='aceleração').length,2);
  const f=fresh().collection[0];
  assert.ok(fighter({...f,trait:'Made in Heaven'}).resistance>fighter(f).resistance);
});
test('reflexo mágico dobra dano, observação interrompe golpe fatal, e a parada do tempo expira',()=>{
  const c=new Combate([[unit('Full Counter')],[unit()]]);
  const m=c.active(0),f=c.active(1);
  c.hit(f,m,{damage:100,magic:true});
  assert.equal(f.hp,9800);assert.equal(m.hp,10000);
  c.hit(f,m,{damage:100,magic:true});assert.equal(m.hp,9900);
  m.trait='Haki da Observação';f.hp=100;
  c.hit(f,m,{damage:500});assert.equal(f.hp,0);assert.equal(m.hp,9900);
  const d=new Combate([[unit('The World')],[unit()]]);
  d.use(d.active(0),d.active(1),'rush');
  assert.ok(d.blocked(d.active(1)));assert.equal(d.active(0).skillReady,0);
  d.time=3000;assert.ok(!d.blocked(d.active(1)));
});
test('Voto consome duas vagas somente quando ativado',()=>{
  const s=fresh(),u=s.collection[0];u.trait='Voto de Nen';
  const change=enabled=>applyGameAction(s,{type:'nen',uid:u.uid,enabled},0);
  assert.equal(change(true),false);const vacated=s.team[3];
  applyGameAction(s,{type:'remove',uid:vacated},0);
  assert.ok(change(true));assert.equal(formationCost(s),4);assert.ok(fighter(u).nen);
  assert.equal(applyGameAction(s,{type:'equip',uid:vacated,slot:3},0),false);
  assert.ok(change(false));assert.ok(applyGameAction(s,{type:'equip',uid:vacated,slot:3},0));
});
test('afinidades especiais são direcionais e toda trait tem raridade e chance',()=>{
  assert.equal(TRAITS.length,17);for(const t of TRAITS)assert.ok(t.odds>0&&t.rarity);
  assert.equal(affinity('Dourado','Branco'),1.5);assert.equal(affinity('Branco','Dourado'),1);assert.equal(affinity('Dourado','Dourado'),2);
});
