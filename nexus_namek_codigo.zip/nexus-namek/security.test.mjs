import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {createNexusServer} from './dev.mjs';
import {createCommunityStore} from './community-store.mjs';
import {advance,advanceWithPresence,CHARACTERS,fresh,WORLDS} from './public/game.js';
import {packCampaign,unpackCampaign} from './public/save.js';
import worker from './public/_worker.js';

function d1Binding(sqlite){
  function prepare(sql,values=[]){
    return {
      bind:(...args)=>prepare(sql,args),
      first:async()=>sqlite.prepare(sql).get(...values)??null,
      run:async()=>({meta:{changes:sqlite.prepare(sql).run(...values).changes}}),
      all:async()=>({results:sqlite.prepare(sql).all(...values)})
    };
  }
  return {prepare,async batch(statements){
    sqlite.exec('BEGIN');try{
      const rows=[];for(const stmt of statements)rows.push(await stmt.all());
      sqlite.exec('COMMIT');return rows;
    }catch(error){sqlite.exec('ROLLBACK');throw error;}
  }};
}

test('cabeçalhos de segurança presentes em _headers, servidor Node e Worker Cloudflare',async t=>{
  const headersFile=await readFile(new URL('./public/_headers',import.meta.url),'utf8');
  assert.match(headersFile,/Content-Security-Policy:.*script-src 'self'.*frame-ancestors 'none'/);
  assert.match(headersFile,/X-Frame-Options:\s*DENY/);
  assert.match(headersFile,/Strict-Transport-Security:/);
  assert.match(headersFile,/Permissions-Policy:/);

  const folder=await mkdtemp(join(tmpdir(),'nexus-sec-'));
  const store=createCommunityStore(join(folder,'db.sqlite'));
  const sqlite=new DatabaseSync(join(folder,'d1.sqlite'));
  const server=createNexusServer(store);
  const address=await once(server.listen(0,'127.0.0.1'),'listening').then(()=>server.address());
  t.after(async()=>{
    await new Promise(resolve=>server.close(resolve));
    store.close();
    sqlite.close();
    await rm(folder,{recursive:true,force:true});
  });

  const html=await fetch(`http://127.0.0.1:${address.port}/`);
  assert.equal(html.status,200);
  assert.equal(html.headers.get('x-frame-options'),'DENY');
  assert.equal(html.headers.get('x-content-type-options'),'nosniff');
  assert.match(html.headers.get('content-security-policy')??'',/script-src 'self'/);
  assert.match(html.headers.get('content-security-policy')??'',/frame-ancestors 'none'/);

  const apiRes=await fetch(`http://127.0.0.1:${address.port}/api/community/account`,{
    method:'POST',headers:{'Content-Type':'application/json'},body:'[]'
  });
  assert.equal(apiRes.status,400);
  assert.equal(apiRes.headers.get('x-frame-options'),'DENY');
  assert.equal(apiRes.headers.get('referrer-policy'),'no-referrer');

  const cfRes=await worker.fetch(new Request('https://nexus.test/api/community/profile'),{NEXUS_DB:d1Binding(sqlite)});
  assert.equal(cfRes.status,401);
  assert.equal(cfRes.headers.get('x-frame-options'),'DENY');
  assert.equal(cfRes.headers.get('referrer-policy'),'no-referrer');
  assert.match(cfRes.headers.get('content-security-policy')??'',/frame-ancestors 'none'/);
});

test('PRNG ChaCha20 com semente de 256 bits é determinístico, distinto e contas online usam semente de 64 hex',()=>{
  const seedA='0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';
  const seedB='fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210';
  const a1=fresh(1000,seedA),a2=fresh(1000,seedA),b1=fresh(1000,seedB);
  advance(a1,1000+600000);
  advance(a2,1000+600000);
  advance(b1,1000+600000);
  assert.deepEqual(a1.collection,a2.collection);
  assert.equal(a1.gold,a2.gold);
  assert.notEqual(JSON.stringify({g:a1.gold,c:a1.collection}),JSON.stringify({g:b1.gold,c:b1.collection}));

  const store=createCommunityStore(':memory:');
  try{
    const acc=store.register('Cripto');
    const synced=store.sync(acc.player.id,null,true,0);
    assert.match(synced.state.seed,/^[0-9a-f]{64}$/);
  }finally{store.close();}
});

test('observationAge retroativo é limitado para não burlar o teto AFK de 12 horas e awayReports tem limite',()=>{
  const HOUR=3600000;
  let now=1000;
  const store=createCommunityStore(':memory:',{now:()=>now});
  try{
    const normal=store.register('Normal');
    const retro=store.register('Retroativo');
    store.sync(normal.player.id,null,true,0);
    store.sync(retro.player.id,null,true,0);

    // 30 horas offline: tentar enviar observationAge de 18h não pode dobrar o limite de 12h.
    now+=30*HOUR;
    const resNormal=store.sync(normal.player.id,null,true,0);
    const resRetro=store.sync(retro.player.id,null,true,18*HOUR);
    // Com clamping em 30s, a diferença máxima de lutas é de no máximo ~3 encontros (30s), nunca 12h (~4000 lutas).
    assert.ok(Math.abs(resRetro.offline.total-resNormal.offline.total)<=10,
      `retro=${resRetro.offline.total} vs normal=${resNormal.offline.total}`);
  }finally{store.close();}

  // awayReports não cresce sem limite
  const s=fresh(0,42);
  let t=0;
  for(let i=0;i<15;i++){
    t+=15*60000;
    advanceWithPresence(s,t,t);
  }
  assert.equal(s.awayReports.length,10);
});

test('unpackCampaign bloqueia injeção de CSS em positions, sprites inválidos e campos adulterados',()=>{
  const base=fresh(1000,77);
  const valid=JSON.parse(packCampaign(base));
  assert.ok(unpackCampaign(JSON.stringify(valid),CHARACTERS,WORLDS));

  const cssInjection=structuredClone(valid);
  cssInjection.campaign.positions['initial-piccolo']=['0;background:url(https://evil.test/x)',50];
  assert.throws(()=>unpackCampaign(JSON.stringify(cssInjection),CHARACTERS,WORLDS));

  const outOfRange=structuredClone(valid);
  outOfRange.campaign.positions['initial-piccolo']=[999,-5];
  assert.throws(()=>unpackCampaign(JSON.stringify(outOfRange),CHARACTERS,WORLDS));

  const badXp=structuredClone(valid);
  badXp.campaign.collection[0].xp=-100;
  assert.throws(()=>unpackCampaign(JSON.stringify(badXp),CHARACTERS,WORLDS));

  const badSprite=structuredClone(valid);
  advance(badSprite.campaign,1000);
  badSprite.campaign.pending.enemy.sprite='../evil';
  assert.throws(()=>unpackCampaign(JSON.stringify(badSprite),CHARACTERS,WORLDS));
});

test('rotação de código de acesso revoga token anterior no servidor Node e no Cloudflare Worker',async t=>{
  const folder=await mkdtemp(join(tmpdir(),'nexus-rot-'));
  const store=createCommunityStore(join(folder,'node.sqlite'));
  const sqlite=new DatabaseSync(join(folder,'d1.sqlite'));
  t.after(async()=>{
    store.close();
    sqlite.close();
    await rm(folder,{recursive:true,force:true});
  });

  const acc=store.register('Rotacao');
  assert.equal(store.authenticate(acc.token),acc.player.id);
  const {token:nextToken}=store.rotateToken(acc.player.id);
  assert.equal(nextToken.length,32);
  assert.notEqual(nextToken,acc.token);
  assert.throws(()=>store.authenticate(acc.token),/inválido/);
  assert.equal(store.authenticate(nextToken),acc.player.id);

  // Worker Cloudflare
  const env={NEXUS_DB:d1Binding(sqlite),ASSETS:{fetch:()=>new Response('OK')}};
  async function api(path,token,body,status=200){
    const headers=token?{Authorization:'Bearer '+token}:{};
    if(body!==undefined)headers['Content-Type']='application/json';
    const res=await worker.fetch(new Request('https://nexus.test/api/'+path,{
      method:body===undefined?'GET':'POST',headers,body:body===undefined?undefined:JSON.stringify(body)
    }),env);
    const data=await res.json();
    assert.equal(res.status,status,JSON.stringify(data));
    return data;
  }
  const cfAcc=await api('community/account',null,{name:'CloudRot'},201);
  const rotated=await api('community/rotate-token',cfAcc.token,{});
  assert.equal(rotated.token.length,32);
  assert.notEqual(rotated.token,cfAcc.token);
  await api('community/profile',cfAcc.token,undefined,401);
  assert.equal((await api('community/profile',rotated.token)).name,'CloudRot');
});

test('convites pendentes recebidos não bloqueiam limite de amigos aceitos e remetente respeita limite de saída',()=>{
  const store=createCommunityStore(':memory:');
  try{
    const target=store.register('Alvo');
    const senders=[];
    for(let i=0;i<22;i++)senders.push(store.register('Bot'+i));
    // Um remetente não pode acumular mais de 20 convites pendentes enviados
    for(let i=1;i<=20;i++)store.requestFriend(senders[0].player.id,senders[i].player.code);
    assert.throws(()=>store.requestFriend(senders[0].player.id,target.player.code),/Limite/);

    // Muitos convites pendentes recebidos por target não impedem que ele aceite amizade legítima
    for(let i=1;i<=21;i++)store.requestFriend(senders[i].player.id,target.player.code);
    store.replyFriend(target.player.id,senders[1].player.id,'accept');
    assert.equal(store.friends(target.player.id).friends.length,1);
  }finally{store.close();}
});
