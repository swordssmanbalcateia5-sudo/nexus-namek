import test from 'node:test';
import assert from 'node:assert/strict';
import {advance,applyGameAction,CHARACTERS,claimDaily,dailyState,fresh,makeBattle,WORLDS} from './public/game.js';
import {packCampaign,unpackCampaign} from './public/save.js';
import {createCommunityStore} from './community-store.mjs';

const day1=Date.parse('2026-11-26T16:00:00Z'); // 13:00 BRT -> ciclo 2026-11-26
const day2=day1+24*3600000;                    // 13:00 BRT -> ciclo 2026-11-27
const day4=day1+72*3600000;                    // pula 1 dia -> quebra streak

function winBattle(s,now,opts={}){
  const b=makeBattle(s,now,!!opts.boss);
  if(opts.elite)b.elite=true;
  b.recruit=opts.recruit??null;
  b.result.winner=0;b.result.reason='eliminação';b.result.events=[];
  s.pending=b;
  advance(s,b.end);
  return b.end;
}

test('missões diárias são determinísticas por ciclo, contam recrutas mesmo com venda automática e resgatam com streak',()=>{
  const s=fresh(day1,42);
  const view0=dailyState(s,day1);
  assert.equal(view0.day,'2026-11-26');
  assert.equal(view0.missions.length,3);
  assert.equal(view0.claimableCount,0);
  // Resgate prematuro falha
  assert.equal(claimDaily(s,view0.missions[0].id,day1),false);
  assert.equal(claimDaily(s,'bonus',day1),false);

  // Ativa venda automática de comuns para provar que recrutas vendidos ainda contam
  s.autoSell={enabled:true,tiers:[1],characters:[]};
  let t=day1+1000;
  for(let i=0;i<22;i++){
    t=winBattle(s,t+1000,{recruit:i<3?{id:'yamcha',shiny:false,trait:null,odds:20}:null});
  }
  const view1=dailyState(s,t);
  assert.equal(view1.allDone,true);
  assert.equal(view1.claimableCount,4);

  const goldBefore=s.gold;
  let gained=0;
  for(const m of view1.missions){
    const r=claimDaily(s,m.id,t);
    assert.equal(r,m.reward);
    gained+=r;
    // Não permite resgate duplicado
    assert.equal(claimDaily(s,m.id,t),false);
  }
  const bonus=claimDaily(s,'bonus',t);
  assert.equal(bonus,view1.bonusReward);
  assert.equal(s.gold,goldBefore+gained+bonus);
  assert.equal(dailyState(s,t).streak,1);
  assert.equal(claimDaily(s,'bonus',t),false);

  // Dia seguinte: progresso zera, mas streak=1 é preservado até completar novamente
  const nextView=dailyState(s,day2);
  assert.equal(nextView.day,'2026-11-27');
  assert.equal(nextView.streak,1);
  assert.equal(nextView.missions.every(m=>m.current===0&&!m.claimed),true);
  assert.ok(nextView.bonusReward>view1.bonusReward); // +10% pelo streak!

  // Pular um dia zera o streak
  assert.equal(dailyState(s,day4).streak,0);

  // Compatibilidade com backup JSON
  const restored=unpackCampaign(packCampaign(s),CHARACTERS,WORLDS);
  assert.deepEqual(restored.daily,s.daily);
});

test('missões diárias funcionam via sync autoritativo no servidor online',()=>{
  let now=day1;
  const store=createCommunityStore(':memory:',{now:()=>now});
  try{
    const {player}=store.register('Diario');
    now+=20*60000;
    const synced=store.sync(player.id,null,true,0);
    const d=dailyState(synced.state,now);
    const done=d.missions.find(m=>m.done);
    assert.ok(done,'20 min de combates devem concluir ao menos uma missão diária');
    const goldBefore=synced.state.gold;
    const claimed=store.sync(player.id,{type:'claimDaily',id:done.id},true,0);
    assert.equal(claimed.changed,true);
    assert.ok(claimed.state.gold>=goldBefore+done.reward);
  }finally{store.close();}
});
