import test from 'node:test';
import assert from 'node:assert/strict';
import {CHARACTERS,UPGRADES,advance,fresh,makeBattle,recruitRates,rollRecruit} from './public/game.js';

test('rastreio dobra todos os pesos raros e registra a chance da combinação sorteada',()=>{
  const base=[.55,.27,.12,.045,.012,.0025,.00045,.00005];
  const boosted=[.37,.27,...base.slice(2).map(v=>v*2)];
  function draw(tier,weights,chance,rare){
    const middle=weights.slice(0,tier-1).reduce((s,v)=>s+v,0)+weights[tier-1]/2;
    const rolls=[0,middle,0,.5,.9,.99];
    return rollRecruit(()=>rolls.shift(),chance,'Dragon Ball',rare);
  }
  for(let tier=1;tier<=8;tier++){
    const old=draw(tier,base,.1,18),next=draw(tier,boosted,.5,36);
    assert.equal(CHARACTERS[old.id].tier,tier);
    assert.equal(old.id,next.id);
    assert.equal(old.shiny,next.shiny);
    const ratio=5*boosted[tier-1]/base[tier-1];
    assert.ok(Math.abs(old.odds/ratio-next.odds)<1);
  }
  const state=fresh(0,2);
  state.upgrades.sorte=UPGRADES.sorte.costs.length;
  for(const luck of UPGRADES.sorte.values){
    for(const tracking of UPGRADES.rastreio.values){
      const rates=recruitRates(luck,tracking);
      assert.equal(rates.encounter,Math.min(50,luck));
      assert.equal(rates.rare,tracking*Math.max(100,50+luck)/100);
    }
  }
  const maxWeights=[.19,.27,...base.slice(2).map(v=>v*3)];
  for(let tier=1;tier<=8;tier++){
    const standard=draw(tier,base,.1,18),max=draw(tier,maxWeights,1,36);
    assert.equal(CHARACTERS[max.id].tier,tier);
    assert.ok(Math.abs(standard.odds/(5*maxWeights[tier-1]/base[tier-1])-max.odds)<1);
  }
  assert.equal(rollRecruit(()=>.5,1),null);
  const encounters=Array.from({length:50},(_,i)=>makeBattle(state,i)).filter(b=>b.recruit);
  assert(encounters.length>0 && encounters.length<50);
  assert.equal(makeBattle(state,51,true).recruit,null);
  state.area=2;state.index=6;
  assert.equal(makeBattle(state,52).recruit,null);
});

test('treino, ouro e enfermaria usam os níveis do início do encontro e aceitam lutas de saves antigos',()=>{
  function setup(){
    const s=fresh(100,13);s.upgrades={treino:4,enfermaria:4,ouro:7};
    const b=makeBattle(s,100);
    b.result.winner=0;b.result.reason='eliminação';b.recruit=null;
    b.result.events=[{type:'cai',actor:'0:0',time:b.result.seconds*1000}];
    s.pending=b;s.upgrades={};
    return {s,b};
  }
  const {s,b}=setup();
  const [entry]=advance(s,b.end);
  assert.equal(entry.gold,Math.round((6+2*b.level)*1.2*1.5));
  assert.equal(entry.xp,Math.round((8+2*b.level)*1.4));
  assert.equal(s.recovery[b.team[0].uid],b.end+12000);
  const {s:old,b:pending}=setup();
  delete pending.goldReward;delete pending.xpBonus;delete pending.recoveryMs;pending.goldBonus=.1;
  const [legacy]=advance(old,pending.end);
  assert.equal(legacy.gold,Math.round((6+2*pending.level)*1.1));
  assert.equal(legacy.xp,8+2*pending.level);
  assert.equal(old.recovery[pending.team[0].uid],pending.end+20000);
});
