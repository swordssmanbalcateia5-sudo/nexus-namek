import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {createNexusServer} from './dev.mjs';
import {createCommunityStore} from './community-store.mjs';
import {dailyCycle,GIFT_GOLD,rarityLabel} from './public/community-rules.js';
import {advance,applyGameAction,fresh} from './public/game.js';

const beforeNoon=Date.parse('2026-11-26T14:59:59.999Z');
const noon=beforeNoon+1;

test('ciclo global é o mesmo para todos e muda ao meio-dia de Brasília',()=>{
  assert.deepEqual(dailyCycle(beforeNoon),{day:'2026-11-25',nextAt:noon});
  assert.deepEqual(dailyCycle(noon),{day:'2026-11-26',nextAt:noon+86400000});
  assert.equal(dailyCycle(Date.parse('2027-01-01T12:00:00Z')).day,'2026-12-31');
  assert.equal(dailyCycle(Date.parse('2018-11-05T12:00:00Z')).nextAt,Date.parse('2018-11-05T14:00:00Z'));
  assert.equal(rarityLabel(100000000),'1/100M');
});

test('pausar e retomar não pula o intervalo e ações rejeitam área e posição inválidas',()=>{
  const time=1000;
  const state=fresh(time,222);
  assert.equal(state.running,true);
  advance(state,time);
  const end=state.pending.end;
  advance(state,end);
  const next=state.nextAt;
  applyGameAction(state,{type:'pause'},end);
  assert.equal(state.running,false);
  applyGameAction(state,{type:'resume'},end+100);
  assert.equal(state.running,true);
  assert.equal(state.nextAt,next);
  assert.equal(applyGameAction(state,{type:'area',area:-1},end),false);
  assert.equal(applyGameAction(state,{type:'position',uid:'initial-piccolo',coords:[Infinity,10]},end),false);
  assert(applyGameAction(state,{type:'position',uid:'initial-piccolo',coords:[120,5]},end));
  assert.deepEqual(state.positions['initial-piccolo'],[92,8]);
});

test('duas contas passam pela API, amizades, presentes, ranking, perfil e reabertura do banco',async t=>{
  const folder=await mkdtemp(join(tmpdir(),'nexus-test-'));
  const file=join(folder,'world.sqlite');
  let timestamp=beforeNoon-16000;
  const store=createCommunityStore(file,{now:()=>timestamp});
  const server=createNexusServer(store);
  const address=await once(server.listen(0,'127.0.0.1'),'listening').then(()=>server.address());
  t.after(async()=>{
    await new Promise(resolve=>server.close(resolve));
    store.close();
    await rm(folder,{recursive:true,force:true});
  });
  async function api(path,token,body,status=200){
    const headers={};
    if(token)headers.Authorization='Bearer '+token;
    if(body!==undefined)headers['Content-Type']='application/json';
    const response=await fetch('http://127.0.0.1:'+address.port+'/api'+path,{
      method:body===undefined?'GET':'POST',headers,body:body===undefined?undefined:JSON.stringify(body),
    });
    const data=await response.json();
    assert.equal(response.status,status,JSON.stringify(data));
    return data;
  }
  await api('/community/profile',null,undefined,401);
  const a=await api('/community/account',null,{name:'Ari'},201);
  const b=await api('/community/account',null,{name:'Bia'},201);
  const action=await api('/game',a.token,{visible:true,state:{gold:1000}});
  assert.equal(action.state.gold,0);
  assert(!Object.hasOwn(action.state,'seed'));
  timestamp=beforeNoon-8000;
  await api('/game',a.token,{visible:true});
  timestamp=beforeNoon;
  await api('/game',a.token,{visible:true});
  await api('/community/friend-request',a.token,{code:b.player.code.toLowerCase()});
  await api('/community/gift',a.token,{id:b.player.id},403);
  await api('/community/friend-reply',a.token,{id:b.player.id,decision:'accept'},409);
  assert.equal((await api('/community/friends',b.token)).requests[0].id,a.player.id);
  await api('/community/friend-reply',b.token,{id:a.player.id,decision:'accept'});
  const goldBeforeGifts=(await api('/game',b.token,{})).state.gold;
  const simultaneous=await Promise.all([
    fetch('http://127.0.0.1:'+address.port+'/api/community/gift',{method:'POST',
      headers:{Authorization:'Bearer '+a.token,'Content-Type':'application/json'},body:JSON.stringify({id:b.player.id})}),
    fetch('http://127.0.0.1:'+address.port+'/api/community/gift',{method:'POST',
      headers:{Authorization:'Bearer '+a.token,'Content-Type':'application/json'},body:JSON.stringify({id:b.player.id})}),
  ]);
  assert.deepEqual(simultaneous.map(r=>r.status).sort(),[200,409]);
  assert.equal((await api('/game',b.token,{})).state.gold,goldBeforeGifts+GIFT_GOLD);
  assert.equal((await api('/community/friends',a.token)).friends[0].sent,1);
  timestamp=noon;
  assert.equal((await api('/community/friends',a.token)).friends[0].sent,0);
  await api('/community/gift',a.token,{id:b.player.id});
  assert.equal((await api('/game',b.token,{})).state.gold,goldBeforeGifts+2*GIFT_GOLD);
  assert.equal((await api('/community/friends',b.token)).inbox.length,2);
  const appearance={background:'aurora',icon:'cometa',border:'ouro'};
  await api('/community/profile',a.token,appearance);
  const fixture=new DatabaseSync(file);
  try{
    const {game}=fixture.prepare('SELECT game FROM players WHERE id=?').get(a.player.id);
    const state=JSON.parse(game);
    state.collection=state.collection.filter(unit=>state.team.includes(unit.uid));
    for(const [i,odds] of [1e8,100,1000,10,2,1e6].entries())state.collection.push({
      id:'beerus',uid:'fixture-'+i,xp:1000,shiny:true,trait:'The World',odds,serial:i+1,
    });
    fixture.prepare('UPDATE players SET game=? WHERE id=?').run(JSON.stringify(state),a.player.id);
  }finally{fixture.close();}
  const ranking=await api('/community/rankings',b.token);
  assert.equal(ranking.rarity[0].odds,100000000);
  assert.equal(ranking.rarity[0].name,'Beerus');
  assert.equal(ranking.power[0].player.id,a.player.id);
  assert(ranking.power[0].units.every(unit=>unit.id==='beerus'));
  assert.equal(ranking.power[0].power,ranking.power[0].units.reduce((sum,unit)=>sum+unit.power,0));
  const other=await api('/community/profile/'+a.player.id,b.token);
  assert.deepEqual(other.appearance,appearance);
  assert(other.playMs>=6000);
  assert(other.encounters>=1);
  assert(other.team.some(unit=>unit.id==='piccolo'));
  assert.deepEqual(other.showcase.map(unit=>unit.odds),[1e8,1e6,1000,100,10]);
  assert(!Object.hasOwn(other,'token'));
  const reopened=createCommunityStore(file,{now:()=>timestamp});
  try{
    assert.equal(reopened.authenticate(b.token),b.player.id);
    assert.equal(reopened.sync(b.player.id,null,false).state.gold,goldBeforeGifts+2*GIFT_GOLD);
  }finally{reopened.close();}
});
