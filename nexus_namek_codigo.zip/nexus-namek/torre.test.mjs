import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {applyGameAction,challengeTower,CHARACTERS,fresh,towerEncounter,towerUnlocked,WORLDS} from './public/game.js';
import {packCampaign,unpackCampaign} from './public/save.js';
import {createCommunityStore} from './community-store.mjs';
import worker from './public/_worker.js';

function strongEndgameState(){
  const s=fresh(1000,77);
  s.world=9;s.unlocked=9;s.completed=true;
  s.journey={9:{area:2,completed:true,finalWins:12}};
  const xp100=1e7;
  s.collection=[
    {uid:'u1',id:'goku',xp:xp100,serial:1,shiny:true,trait:'Made in Heaven',odds:1e9},
    {uid:'u2',id:'beerus',xp:xp100,serial:1,shiny:true,trait:'Haki do Rei',odds:1e8},
    {uid:'u3',id:'gojo',xp:xp100,serial:1,shiny:true,trait:'The World',odds:1e8},
    {uid:'u4',id:'luminous',xp:xp100,serial:1,shiny:true,trait:'Instinto Superior',odds:1e7},
  ];
  s.slots=['u1','u2','u3','u4'];
  s.team=['u1','u2','u3','u4'];
  s.leader='u1';
  s.positions={u1:[74,44],u2:[56,76],u3:[36,26],u4:[22,60]};
  return s;
}

test('torre bloqueia antes do Mundo 10, libera após vencer Boros e escala 4x2 -> 4x3 -> 4x4 com marcos',()=>{
  const locked=fresh(1000,11);
  assert.equal(towerUnlocked(locked),false);
  assert.equal(challengeTower(locked),false);

  // Confirma composição determinística por faixa de andares
  assert.equal(towerEncounter(1).count,2);
  assert.equal(towerEncounter(4).count,2);
  assert.equal(towerEncounter(5).count,3);
  assert.equal(towerEncounter(5).milestone,true);
  assert.ok(towerEncounter(5).milestoneBonus>0);
  assert.equal(towerEncounter(10).count,4);
  assert.equal(towerEncounter(10).milestone,true);

  const s=strongEndgameState();
  assert.equal(towerUnlocked(s),true);
  // Viajar de volta para Namek mantém Torre liberada via journey[9].completed
  assert.equal(applyGameAction(s,{type:'world',index:0},1000),true);
  assert.equal(s.world,0);
  assert.equal(towerUnlocked(s),true);

  const goldStart=s.gold;
  let expectedGold=0;
  for(let floor=1;floor<=5;floor++){
    const enc=towerEncounter(floor);
    const run=challengeTower(s);
    assert.ok(run);
    assert.equal(run.floor,floor);
    assert.equal(run.won,true);
    assert.equal(s.tower.bestFloor,floor);
    expectedGold+=enc.reward;
    assert.ok(run.allies.some(a=>a.damage>0));
  }
  assert.equal(s.gold,goldStart+expectedGold);
  assert.equal(s.tower.lastRun.milestone,true);

  const restored=unpackCampaign(packCampaign(s),CHARACTERS,WORLDS);
  assert.equal(restored.tower.bestFloor,5);
});

test('ranking da Torre funciona em Node SQLite e no Worker do Cloudflare D1',async()=>{
  // 1. Node SQLite
  const dir=mkdtempSync(join(tmpdir(),'nexus-tower-'));
  const file=join(dir,'tower.sqlite');
  const store=createCommunityStore(file,{now:()=>5000});
  try{
    const a=store.register('Topo');
    const b=store.register('Base');
    assert.deepEqual(store.rankings().tower,[]);
    const ext=new DatabaseSync(file);
    try{ext.prepare('UPDATE players SET game=? WHERE id=?').run(JSON.stringify(strongEndgameState()),a.player.id);}finally{ext.close();}
    const climb=store.sync(a.player.id,{type:'tower'},true,0);
    assert.equal(climb.changed,true);
    assert.equal(climb.state.tower.bestFloor,1);
    const r=store.rankings();
    assert.equal(r.tower.length,1);
    assert.equal(r.tower[0].player.id,a.player.id);
    assert.equal(r.tower[0].floor,1);
    assert.equal(store.profile(a.player.id).towerFloor,1);
    assert.equal(store.profile(b.player.id).towerFloor,0);
  }finally{store.close();rmSync(dir,{recursive:true,force:true});}

  // 2. Cloudflare Worker D1 binding
  const sqlite=new DatabaseSync(':memory:');
  function binding(db){
    function prepare(sql,values=[]){
      return {
        bind:(...args)=>prepare(sql,args),
        first:async()=>db.prepare(sql).get(...values)??null,
        run:async()=>({meta:{changes:db.prepare(sql).run(...values).changes}}),
        all:async()=>({results:db.prepare(sql).all(...values)})
      };
    }
    return {prepare,async batch(stmts){
      db.exec('BEGIN');try{
        const rows=[];for(const st of stmts)rows.push(await st.all());
        db.exec('COMMIT');return rows;
      }catch(e){db.exec('ROLLBACK');throw e;}
    }};
  }
  const env={NEXUS_DB:binding(sqlite),ASSETS:{fetch:()=>new Response('ok')}};
  async function api(path,token,body){
    const headers=token?{Authorization:'Bearer '+token}:{};
    if(body!==undefined)headers['Content-Type']='application/json';
    const res=await worker.fetch(new Request('https://nexus.test/api/'+path,{method:body===undefined?'GET':'POST',headers,body:JSON.stringify(body)}),env);
    return res.json();
  }
  const p=await api('community/account',null,{name:'Escalador'});
  const end=strongEndgameState();
  sqlite.prepare('UPDATE nexus_players SET game=? WHERE id=?').run(JSON.stringify(end),p.player.id);
  const res=await api('game',p.token,{action:{type:'tower'},visible:true});
  assert.equal(res.changed,true);
  assert.equal(res.state.tower.bestFloor,1);
  const ranks=await api('community/rankings',p.token);
  assert.equal(ranks.tower.length,1);
  assert.equal(ranks.tower[0].player.id,p.player.id);
  assert.equal(ranks.tower[0].floor,1);
  const prof=await api('community/profile',p.token);
  assert.equal(prof.towerFloor,1);
  sqlite.close();
});
