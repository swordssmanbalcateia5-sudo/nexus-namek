# Nexus · Continuação do desenvolvimento

O Nexus é um RPG de exploração automática com campanha solo, formação de quatro vagas e coleção de personagens de anime. Este pacote é uma cópia editável da build com backup de progresso. Abra CATALOGO.md para consultar o elenco, as habilidades especiais, as traits e os inimigos usados nessa versão.

## Rodar e validar

Para jogar solo, baixe jogar_namek.html na raiz do repositório ou gere o arquivo com `npm run standalone -- jogar_namek.html`. Para desenvolver e testar a Comunidade, use Node.js 24 e execute os comandos abaixo na pasta que contém package.json. O projeto usa as bibliotecas nativas do Node, incluindo SQLite.

```sh
npm test
npm start
```

Abra http://localhost:4173 no navegador. Para experimentar amizades e presentes, siga o roteiro com dois perfis em LEIA-ME.md. Edite os arquivos de public/ e, ao terminar, gere o HTML portátil com `npm run standalone -- jogar_namek.html`.

## Onde editar

| Mudança | Arquivos |
| --- | --- |
| Personagens, traits, upgrades, formação, auto-venda, mundos, encontros e recompensas AFK | public/game.js |
| Habilidades, passivas e eventos do replay de combate | public/engine.js |
| Arena das bolas, colisões, bônus e dano | public/duel.js |
| Fichas abertas ao clicar, guia, coleção, formação e configurações | public/app.js, public/index.html, public/style.css |
| Sprites ativos, variantes Shiny e inimigos | public/art/ e função spriteFor em public/game.js |
| Materiais de arte complementares | Extraia nexus-arte-reserva.zip junto da pasta nexus-namek/ para restaurar arte-reserva/ |
| Save solo, cópia anterior e backup portátil | public/save.js, public/app.js e save.test.mjs |
| Perfis, rankings, amizades, presentes e horário diário | public/community.js, public/community-rules.js, community-store.mjs e dev.mjs |
| Cache offline e empacotamento da build | public/sw.js e standalone.mjs |

## Regras para conferir depois de uma mudança

- Exploração começa automaticamente. Um combate pendente precisa ser resolvido antes do próximo encontro. O retorno após dez minutos de ausência pode gerar um relatório AFK, com simulação de até doze horas.
- Na formação, remover um titular deixa a vaga livre para escolher outro na coleção. O tempo de recuperação é de 20 segundos e a derrota da equipe inteira aplica recuperação coletiva.
- Na arena, colisões aumentam a força em até 40%. A interface identifica quem acertou e atualiza o dano do personagem.
- A venda automática guarda a primeira cópia normal e a primeira Shiny de cada personagem. Em recrutamentos posteriores, uma trait permitida pode ser vendida mesmo na primeira vez que aparece nessa variante. Exceções para traits são configuradas por raridade do personagem.
- Atualizações precisam ler os saves existentes na chave nexus.namek.v1. Para validar uma migração, teste um save de uma build anterior e faça uma exportação e uma importação em Configurações.
- O modo solo usa o armazenamento do navegador. A Comunidade usa um servidor compartilhado com SQLite. No Cloudflare Pages, a Comunidade usa o Worker incluído em public/ e o vínculo D1 NEXUS_DB.

## Origem

A entrega pública de referência usa o commit 7093316 do repositório swordssmanbalcateia5-sudo/nexus-namek. O código editável está extraído neste pacote. Os dados pessoais de jogo ficam no navegador de cada jogador ou no banco de uma instância do servidor.

https://github.com/swordssmanbalcateia5-sudo/nexus-namek
