import {serialSchema,issueSerials} from './serials.mjs';
import {DatabaseSync} from 'node:sqlite';
import {createHash,randomBytes,randomUUID} from 'node:crypto';
import {advance,advanceWithPresence,applyGameAction,CHARACTERS,fighter,fresh} from './public/game.js';
import {dailyCycle,DEFAULT_PROFILE,GIFT_GOLD,appearancePatch} from './public/community-rules.js';

export class CommunityError extends Error {
  constructor(status,message){super(message);this.status=status;}
}
const fail=(status,message)=>{throw new CommunityError(status,message);};
const tokenHash=token=>createHash('sha256').update(token).digest('hex');
const statNames=['hp','attack','magic','defense','resistance','speed'];
const rankLimit=30;
const maxFriends=40;

function summarizeUnit(unit){
  const stats=fighter(unit);
  return {id:unit.id,xp:unit.xp,name:CHARACTERS[unit.id].name,level:stats.level,shiny:unit.shiny,trait:unit.trait,stars:stats.stars,nen:unit.nen===true,serial:unit.serial,odds:unit.odds,
    power:statNames.reduce((sum,key)=>sum+stats[key],0)};
}
const byRarity=(a,b)=>(b.odds??0)-(a.odds??0)||a.name.localeCompare(b.name)||a.serial-b.serial;
const byPower=(a,b)=>b.power-a.power||byRarity(a,b);
const ref=row=>({id:row.id,name:row.name,code:row.code});

export function createCommunityStore(filename,{now=Date.now}={}){
  const db=new DatabaseSync(filename);
  db.exec(`
    PRAGMA journal_mode=WAL;
    PRAGMA foreign_keys=ON;
    PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS players(
      id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, token_hash TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL, game TEXT NOT NULL, appearance TEXT NOT NULL,
      play_ms INTEGER NOT NULL DEFAULT 0, last_seen INTEGER
    );
    CREATE TABLE IF NOT EXISTS friendships(
      a TEXT NOT NULL REFERENCES players(id), b TEXT NOT NULL REFERENCES players(id),
      requested_by TEXT NOT NULL REFERENCES players(id), accepted INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY(a,b), CHECK(a<b)
    );
    CREATE INDEX IF NOT EXISTS friendships_b ON friendships(b);
    CREATE TABLE IF NOT EXISTS gifts(
      sender TEXT NOT NULL REFERENCES players(id), recipient TEXT NOT NULL REFERENCES players(id),
      day TEXT NOT NULL, gold INTEGER NOT NULL, sent_at INTEGER NOT NULL,
      PRIMARY KEY(sender,recipient,day)
    );
    CREATE INDEX IF NOT EXISTS gifts_recipient ON gifts(recipient,sent_at DESC);
  `);
  function transaction(work){
    db.exec('BEGIN IMMEDIATE');
    try{const result=work();db.exec('COMMIT');return result;}
    catch(error){db.exec('ROLLBACK');throw error;}
  }
  transaction(()=>{for(const sql of serialSchema('players',false))db.exec(sql);});
  const counter=()=>db.prepare('SELECT * FROM nexus_serials WHERE id=1').get();
  const player=id=>db.prepare('SELECT * FROM players WHERE id=?').get(id);
  const update=(id,state)=>db.prepare('UPDATE players SET game=? WHERE id=?').run(JSON.stringify(state),id);
  const pair=(a,b)=>a<b?[a,b]:[b,a];
  function relationship(a,b){return db.prepare('SELECT * FROM friendships WHERE a=? AND b=?').get(...pair(a,b));}
  let rankingsCache=null,rankingsVersion='',localWriteVersion=0;
  const dbVersion=()=>`${db.prepare('PRAGMA data_version').get().data_version}:${localWriteVersion}`;

  function register(name){
    name=typeof name==='string'?name.normalize('NFC').trim().replace(/\s+/gu,' '):'';
    if(!/^[\p{L}\p{N} _.-]{2,24}$/u.test(name))fail(400,'Use de 2 a 24 letras ou números no nome. Espaço, ponto, hífen e sublinhado são aceitos.');
    const token=randomBytes(24).toString('base64url');
    const id=randomUUID();
    return transaction(()=>{
      let code;
      do{code=randomBytes(5).toString('hex').toUpperCase();}
      while(db.prepare('SELECT 1 FROM players WHERE code=?').get(code));
      const state=fresh(now(),randomBytes(4).readUInt32LE());
      issueSerials(state,state.collection,counter());
      db.prepare('INSERT INTO players(id,code,token_hash,name,game,appearance) VALUES(?,?,?,?,?,?)')
        .run(id,code,tokenHash(token),name,JSON.stringify(state),JSON.stringify(DEFAULT_PROFILE));
      localWriteVersion++;
      return {token,player:{id,code,name}};
    });
  }
  function authenticate(token){
    if(typeof token!=='string'||!/^[A-Za-z0-9_-]{32}$/.test(token))fail(401,'Entre na sua conta da comunidade.');
    const row=db.prepare('SELECT id FROM players WHERE token_hash=?').get(tokenHash(token));
    if(!row)fail(401,'Código de acesso inválido.');
    return row.id;
  }
  function sync(id,action,visible,observationAge=visible?0:null){
    return transaction(()=>{
      const row=player(id);
      const timestamp=now();
      const state=JSON.parse(row.game);
      const previous=state.pending;
      const seen=Number.isFinite(observationAge)&&observationAge>=0?timestamp-observationAge:null;
      const entries=advanceWithPresence(state,timestamp,seen);
      const end=entries.at(-1);
      const finished=previous&&end?.end===previous.end?{battle:previous,entry:end}:null;
      const changed=applyGameAction(state,action,timestamp);
      if(changed)entries.push(...advance(state,timestamp));
      issueSerials(state,entries.map(e=>e.recruit||e.sold).filter(Boolean),counter());
      const delta=timestamp-(row.last_seen??timestamp);
      const played=delta>0&&delta<=20000?delta:0;
      db.prepare('UPDATE players SET game=?,play_ms=play_ms+?,last_seen=? WHERE id=?')
        .run(JSON.stringify(state),played,visible?timestamp:null,id);
      if(changed||entries.length)localWriteVersion++;
      return {state,entries:entries.slice(-25),offline:{total:entries.length,wins:entries.filter(e=>e.won).length,gold:entries.reduce((sum,e)=>sum+e.gold,0),
        recruits:entries.filter(e=>e.recruit).length},changed,finished,now:timestamp,player:ref(row)};
    });
  }
  function profile(id){
    const row=player(id);
    if(!row)fail(404,'Jogador não encontrado.');
    const state=JSON.parse(row.game);
    const units=state.collection.map(summarizeUnit);
    return {...ref(row),appearance:JSON.parse(row.appearance),playMs:row.play_ms,encounters:state.wins+state.losses,
      leaderId:state.collection.find(u=>u.uid===state.leader)?.id,
      team:state.team.map(uid=>summarizeUnit(state.collection.find(unit=>unit.uid===uid))),showcase:units.filter(unit=>unit.odds>0).sort(byRarity).slice(0,5)};
  }
  function customize(id,input){
    let patch;
    try{patch=appearancePatch(input);}catch(error){fail(400,error.message);}
    db.prepare('UPDATE players SET appearance=json_patch(appearance,?) WHERE id=?').run(JSON.stringify(patch),id);
    return profile(id);
  }
  function rankings(){
    const version=dbVersion();
    if(rankingsCache&&rankingsVersion===version)return rankingsCache;
    const rarity=[],power=[];
    for(const row of db.prepare('SELECT id,name,game FROM players').iterate()){
      const state=JSON.parse(row.game);
      const units=state.collection.map(summarizeUnit);
      const player={id:row.id,name:row.name};
      // Only the best entries from a player can reach the global limit.
      rarity.push(...units.filter(unit=>unit.odds>0).sort(byRarity).slice(0,rankLimit).map(unit=>({...unit,player})));
      const top=units.sort(byPower).slice(0,4);
      power.push({player,power:top.reduce((sum,unit)=>sum+unit.power,0),units:top});
    }
    rankingsCache={rarity:rarity.sort((a,b)=>byRarity(a,b)||a.player.id.localeCompare(b.player.id)).slice(0,rankLimit),
      power:power.sort((a,b)=>b.power-a.power||a.player.name.localeCompare(b.player.name)||a.player.id.localeCompare(b.player.id)).slice(0,rankLimit)};
    rankingsVersion=version;
    return rankingsCache;
  }
  function requestFriend(id,code){
    if(typeof code!=='string'||!/^[0-9a-f]{10}$/i.test(code.trim()))fail(400,'Informe o código de amigo com 10 caracteres.');
    const friend=db.prepare('SELECT id FROM players WHERE code=?').get(code.trim().toUpperCase());
    if(!friend)fail(404,'Código de amigo não encontrado.');
    if(friend.id===id)fail(400,'Esse é o seu próprio código.');
    return transaction(()=>{
      if(relationship(id,friend.id))fail(409,'Já existe uma amizade ou um convite entre vocês.');
      const count=db.prepare('SELECT count(*) AS n FROM friendships WHERE a=? OR b=?');
      if(count.get(id,id).n>=maxFriends||count.get(friend.id,friend.id).n>=maxFriends)fail(409,'Limite de amigos ou convites atingido.');
      db.prepare('INSERT INTO friendships(a,b,requested_by) VALUES(?,?,?)').run(...pair(id,friend.id),id);
    });
  }
  function replyFriend(id,other,decision){
    if(typeof other!=='string'||!['accept','remove'].includes(decision))fail(400,'Resposta inválida.');
    return transaction(()=>{
      const relation=relationship(id,other);
      if(!relation)fail(404,'Amizade ou convite não encontrado.');
      if(decision==='remove')db.prepare('DELETE FROM friendships WHERE a=? AND b=?').run(...pair(id,other));
      else{
        if(relation.accepted||relation.requested_by===id)fail(409,'Esse convite não pode ser aceito por você.');
        db.prepare('UPDATE friendships SET accepted=1 WHERE a=? AND b=?').run(...pair(id,other));
      }
    });
  }
  function sendGift(id,recipient){
    if(typeof recipient!=='string')fail(400,'Escolha um amigo para receber o presente.');
    return transaction(()=>{
      if(!relationship(id,recipient)?.accepted)fail(403,'Presentes são exclusivos para amigos confirmados.');
      const timestamp=now();
      const {day}=dailyCycle(timestamp);
      const result=db.prepare('INSERT OR IGNORE INTO gifts(sender,recipient,day,gold,sent_at) VALUES(?,?,?,?,?)')
        .run(id,recipient,day,GIFT_GOLD,timestamp);
      if(!result.changes)fail(409,'Você já enviou um presente a esse amigo neste ciclo.');
      const state=JSON.parse(player(recipient).game);
      state.gold+=GIFT_GOLD;
      update(recipient,state);
      return {gold:GIFT_GOLD};
    });
  }
  function friends(id){
    const timestamp=now();
    const cycle=dailyCycle(timestamp);
    const connections=db.prepare(`
      SELECT p.id,p.name,p.code,f.accepted,f.requested_by,
        EXISTS(SELECT 1 FROM gifts g WHERE g.sender=? AND g.recipient=p.id AND g.day=?) AS sent
      FROM friendships f JOIN players p ON p.id=CASE WHEN f.a=? THEN f.b ELSE f.a END
      WHERE f.a=? OR f.b=? ORDER BY p.name,p.id
    `).all(id,cycle.day,id,id,id);
    const inbox=db.prepare(`
      SELECT p.id,p.name,g.gold,g.sent_at AS sentAt FROM gifts g JOIN players p ON p.id=g.sender
      WHERE g.recipient=? ORDER BY g.sent_at DESC LIMIT 20
    `).all(id);
    return {friends:connections.filter(row=>row.accepted),requests:connections.filter(row=>!row.accepted),
      inbox,cycle,now:timestamp,giftGold:GIFT_GOLD};
  }
  return {register,authenticate,sync,profile,customize,rankings,requestFriend,replyFriend,sendGift,friends,close:()=>db.close()};
}
