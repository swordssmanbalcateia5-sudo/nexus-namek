import test from 'node:test';
import assert from 'node:assert/strict';
import {collisionBonus,createDuel,stepDuel} from './public/duel.js';
import {fresh,fighter} from './public/game.js';

test('arena tem colisões, assistência e revezamento até o resultado',()=>{
  const team=fresh().collection.map(u=>fighter(u));
  const match=createDuel(team,team);
  for(let i=0;i<7300&&match.result===null;i++)stepDuel(match);
  assert.ok(match.contacts>1);
  assert.ok(match.combat.log.some(e=>e.type==='cura'));
  assert.ok(match.combat.log.some(e=>e.type==='entra'));
  assert.ok(['Vitória','Derrota','Empate'].includes(match.result));
  const elapsed=match.t;
  stepDuel(match);
  assert.equal(match.t,elapsed);
});

test('bônus individual de colisão satura no quarto acerto',()=>{
  assert.deepEqual([0,1,2,3,4,5,100].map(collisionBonus),[0,12,24,36,40,40,40]);
});
