import test from 'node:test';
import assert from 'node:assert/strict';
import {advance,advanceWithPresence,applyGameAction,buyUpgrade,fresh,UPGRADES,waitFor} from './public/game.js';
import {createCommunityStore} from './community-store.mjs';
const minute=60000;
test('retorno AFK inclui capturas e XP creditada para todos os encontros e não repete ao confirmar',()=>{
  const s=fresh(1000,177),now=1000+25*minute;
  s.upgrades.xp=2;
  s.collection.push({...s.collection[0],uid:'reserve'});
  const before=s.collection.length;
  const entries=advanceWithPresence(s,now,now);
  const [r]=s.awayReports;
  assert.ok(entries.length>25);
  assert.equal(r.encounters,entries.length);
  assert.equal(r.gold,s.gold);
  assert.equal(r.teamXp,s.collection.slice(0,4).reduce((v,u)=>v+u.xp,0));
  assert.equal(r.reserveXp,entries.reduce((sum,e)=>sum+e.reserveXp,0));assert.ok(s.collection[4].xp>0);
  assert.equal(r.lastRecruit-r.firstRecruit,entries.filter(e=>e.recruit).length);
  assert.equal(r.firstRecruit,before);
  const restored=JSON.parse(JSON.stringify(s));
  advanceWithPresence(restored,now+10,now+10);
  assert.equal(restored.awayReports.length,1);
  assert.ok(applyGameAction(restored,{type:'dismissAway',end:r.end},now+10));
  assert.equal(restored.awayReports.length,0);
});
test('inatividade em aba aberta soma os lotes e respeita a fronteira de dez minutos',()=>{
  const s=fresh(0,77);
  advanceWithPresence(s,10*minute-1,10*minute-1);
  assert.ok(!s.awayReports?.length);
  const initialWins=s.wins,initialGold=s.gold;
  for(let i=1;i<10;i++)advanceWithPresence(s,(10+i)*minute-1,null);
  const end=20*minute-1;
  advanceWithPresence(s,end,end);
  assert.equal(s.awayReports[0].gold,s.gold-initialGold);
  assert.equal(s.awayReports[0].wins,s.wins-initialWins);
});
test('teto de 12 horas vale para toda a ausência; formação parada gera resumo zerado',()=>{
  const baseline=fresh(500,551),s=structuredClone(baseline);
  advance(baseline,500+720*minute);
  for(const mins of [5,8,720,732,800])advanceWithPresence(s,500+mins*minute,null);
  advanceWithPresence(s,500+810*minute,500+810*minute);
  assert.equal(s.gold,baseline.gold);assert.equal(s.awayReports[0].end-s.awayReports[0].start,810*minute);
  const paused=fresh(1,77);paused.running=false;paused.paused=true;
  advanceWithPresence(paused,600001,600001);
  assert.equal(paused.awayReports[0].encounters,0);
});
test('conta online preserva o relatório completo e a confirmação',()=>{
  let now=1000;const store=createCommunityStore(':memory:',{now:()=>now});
  try{
    const {player}=store.register('Explorador');
    store.sync(player.id,null,true,0);now+=35*minute;
    const result=store.sync(player.id,null,true,0);
    const report=result.state.awayReports[0];assert.ok(report.encounters>25);assert.equal(report.encounters,result.offline.total);
    assert.equal(store.sync(player.id,{type:'dismissAway',end:now},true,0).state.awayReports.length,0);
  }finally{store.close();}
});
test('cada compra valida o mundo, o saldo, a progressão e o teto',()=>{
  for(const [id,up] of Object.entries(UPGRADES)){
    const s=fresh(0,99);
    for(const [i,cost] of up.costs.entries()){
      s.gold=cost;
      if(up.worlds[i]>1){s.unlocked=up.worlds[i]-2;assert.equal(buyUpgrade(s,id),false);}
      s.unlocked=up.worlds[i]-1;s.gold--;assert.equal(buyUpgrade(s,id),false);
      s.gold++;assert.ok(buyUpgrade(s,id));assert.equal(s.gold,0);
    }
    s.gold=1e6;assert.equal(buyUpgrade(s,id),false);
    if(id==='ritmo')assert.equal(waitFor(s),5000);
  }
});
