import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {applyGameAction,challengeDailyRaid,CHARACTERS,dailyRaidBoss,dailyRaidState,fresh,MAX_RAID_ATTEMPTS,WORLDS} from './public/game.js';
import {packCampaign,unpackCampaign} from './public/save.js';
import {createCommunityStore} from './community-store.mjs';
import worker from './public/_worker.js';

const day1=Date.parse('2026-11-26T16:00:00Z'); // 13:00 BRT -> 2026-11-26
const day2=day1+24*3600000;                    // 13:00 BRT -> 2026-11-27

test('raid diária rotaciona chefe por dailyCycle, limita a 3 tentativas e reseta no dia seguinte preservando recorde',()=>{
  const b1=dailyRaidBoss('2026-11-26');
  const b1Again=dailyRaidBoss('2026-11-26');
  assert.deepEqual(b1,b1Again);
  assert.equal(b1.hp,10000000);

  const s=fresh(day1,81);
  // Sobe um pouco os iniciais para causar dano consistente
  for(const u of s.collection)u.xp=50000;
  const goldStart=s.gold;
  let totalReward=0,maxDamage=0;
  for(let i=1;i<=MAX_RAID_ATTEMPTS;i++){
    const run=challengeDailyRaid(s,day1+i*1000);
    assert.ok(run);
    assert.equal(run.attempt,i);
    assert.ok(run.damage>0);
    assert.ok(run.reward>=60);
    totalReward+=run.reward;
    maxDamage=Math.max(maxDamage,run.damage);
  }
  assert.equal(s.gold,goldStart+totalReward);
  assert.equal(dailyRaidState(s,day1).remaining,0);
  assert.equal(dailyRaidState(s,day1).bestDamage,maxDamage);
  // 4ª tentativa no mesmo ciclo é bloqueada
  assert.equal(challengeDailyRaid(s,day1+5000),false);

  // Dia seguinte: tentativas resetam para 3 e bestEver é preservado
  const nextView=dailyRaidState(s,day2);
  assert.equal(nextView.day,'2026-11-27');
  assert.equal(nextView.remaining,MAX_RAID_ATTEMPTS);
  assert.equal(nextView.bestDamage,0);
  assert.equal(nextView.bestEver,maxDamage);
  assert.equal(applyGameAction(s,{type:'raid'},day2),true);
  assert.equal(dailyRaidState(s,day2).remaining,MAX_RAID_ATTEMPTS-1);

  const restored=unpackCampaign(packCampaign(s),CHARACTERS,WORLDS);
  assert.equal(restored.raid.bestEver,s.raid.bestEver);
});

test('ranking diário da Raid funciona em Node SQLite (com invalidação na virada do ciclo) e no Worker do Cloudflare D1',async()=>{
  // 1. Node SQLite com relógio controlado
  let now=day1;
  const store=createCommunityStore(':memory:',{now:()=>now});
  try{
    const a=store.register('Atacante');
    const b=store.register('Defensor');
    assert.deepEqual(store.rankings().raid,[]);
    const r1=store.sync(a.player.id,{type:'raid'},true,0);
    assert.equal(r1.changed,true);
    assert.ok(r1.state.raid.bestDamage>0);
    const rankDay1=store.rankings();
    assert.equal(rankDay1.raidDay,'2026-11-26');
    assert.equal(rankDay1.raid.length,1);
    assert.equal(rankDay1.raid[0].player.id,a.player.id);
    assert.equal(rankDay1.raid[0].damage,r1.state.raid.bestDamage);
    assert.equal(store.profile(a.player.id).raidToday,r1.state.raid.bestDamage);
    assert.equal(store.profile(b.player.id).raidToday,0);

    // Virada do meio-dia invalida cache de rankings automaticamente
    now=day2;
    const rankDay2=store.rankings();
    assert.equal(rankDay2.raidDay,'2026-11-27');
    assert.deepEqual(rankDay2.raid,[]);
  }finally{store.close();}

  // 2. Cloudflare Worker D1 binding
  const sqlite=new DatabaseSync(':memory:');
  function binding(db){
    function prepare(sql,values=[]){
      return {
        bind:(...args)=>prepare(sql,args),
        first:async()=>db.prepare(sql).get(...values)??null,
        run:async()=>({meta:{changes:db.prepare(sql).run(...values).changes}}),
        all:async()=>({results:db.prepare(sql).all(...values)})
      };
    }
    return {prepare,async batch(stmts){
      db.exec('BEGIN');try{
        const rows=[];for(const st of stmts)rows.push(await st.all());
        db.exec('COMMIT');return rows;
      }catch(e){db.exec('ROLLBACK');throw e;}
    }};
  }
  const env={NEXUS_DB:binding(sqlite),ASSETS:{fetch:()=>new Response('ok')}};
  async function api(path,token,body){
    const headers=token?{Authorization:'Bearer '+token}:{};
    if(body!==undefined)headers['Content-Type']='application/json';
    const res=await worker.fetch(new Request('https://nexus.test/api/'+path,{method:body===undefined?'GET':'POST',headers,body:JSON.stringify(body)}),env);
    return res.json();
  }
  const p=await api('community/account',null,{name:'Raider'});
  const res=await api('game',p.token,{action:{type:'raid'},visible:true});
  assert.equal(res.changed,true);
  assert.ok(res.state.raid.bestDamage>0);
  const ranks=await api('community/rankings',p.token);
  assert.equal(ranks.raid.length,1);
  assert.equal(ranks.raid[0].player.id,p.player.id);
  assert.equal(ranks.raid[0].damage,res.state.raid.bestDamage);
  const prof=await api('community/profile',p.token);
  assert.equal(prof.raidBestEver,res.state.raid.bestDamage);
  sqlite.close();
});
