# Alca RNG Build 61 no Node.js

## Teste no seu computador

1. Instale o Node.js 24 pelo site oficial e extraia o ZIP.
2. Abra um terminal na pasta que contém `package.json` e execute `npm start`.
3. Abra `http://127.0.0.1:4173/` e crie uma conta de teste. Para verificar a API, abra `http://127.0.0.1:4173/api/health`.

O comando cria um SQLite em `data/alca.sqlite` para o teste. As dependências já vêm no Node.js. O comando `npm test` executa os testes do jogo.

## Teste com a cópia do banco do Cloudflare

Com o Wrangler autenticado no Cloudflare, exporte uma cópia do banco existente:

```sh
npx wrangler d1 export NOME_DO_BANCO --remote --output=backup-d1.sql
npm run import-d1 -- backup-d1.sql data/alca-migrado.sqlite
```

O primeiro comando usa o nome do banco no painel, que pode ser diferente de `NEXUS_DB`. Guarde o arquivo SQL em um local privado. O importador exige um novo arquivo de destino, confere a integridade e imprime a quantidade de contas encontradas.

Copie `.env.example` para `.env` e ajuste `ALCA_DB=./data/alca-migrado.sqlite`. Reinicie com `npm start` e entre pelo código de acesso de uma conta existente. Confira o progresso, a lista de personagens e a sincronização.

## Deploy na instância Linux

1. Instale Node.js 24 e Caddy. Crie um usuário de sistema `alca`, coloque os arquivos do pacote em `/opt/alca-rng` e dê a esse usuário acesso de leitura ao pacote e escrita na pasta de dados. Use uma pasta persistente fora de `public/`, por exemplo `/var/lib/alca-rng`. O arquivo `.env` deve ser legível apenas por quem executa o serviço.
2. No `.env`, configure `ALCA_HOST=127.0.0.1`, `ALCA_PORT=4173`, `ALCA_DB=/var/lib/alca-rng/alca.sqlite`, `ALCA_PUBLIC_URL=https://jogo.seudominio.com.br` e `ALCA_TRUST_PROXY=1`. Use o domínio real e o caminho exato do arquivo SQLite importado.
3. No Lightsail, associe um IP estático, libere as portas 80 e 443 e aponte o DNS do domínio para esse IP. Use `deploy/Caddyfile` como modelo para o Caddy e substitua o domínio. Mantenha o Node na porta local 4173 e passe o tráfego externo pelo Caddy.
4. Copie `deploy/alca-rng.service` para `/etc/systemd/system/`. Execute `command -v node` e ajuste `ExecStart` se o caminho do Node for diferente. Habilite e inicie o serviço com `sudo systemctl daemon-reload` e `sudo systemctl enable --now alca-rng`.
5. Para login pelo Google ou Discord, adicione as respectivas variáveis de ambiente da amostra ao `.env` e registre os retornos `https://jogo.seudominio.com.br/api/auth/google/callback` e `https://jogo.seudominio.com.br/api/auth/discord/callback` no provedor. O código de acesso funciona sem essas integrações.
6. Teste `/api/health` pelo domínio HTTPS, a entrada com uma conta existente e um ciclo de exploração. Para a migração definitiva, pause as gravações no Cloudflare e importe uma nova exportação em um arquivo SQLite novo antes de iniciar a produção na AWS. Faça backups do banco usando a API de backup do SQLite ou com o serviço parado.

O pacote fornece o servidor e os modelos de configuração. A contratação e a configuração da instância são feitas no painel da AWS.
