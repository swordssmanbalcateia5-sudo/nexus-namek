import {DatabaseSync} from 'node:sqlite';
import {existsSync,linkSync,mkdirSync,mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';

const [input,output]=process.argv.slice(2);
if(!input||!output){
  console.error('Uso: npm run import-d1 -- backup-d1.sql caminho/novo-alca.sqlite');
  process.exit(2);
}
const target=resolve(output);
if(existsSync(target))throw Error('O destino já existe. Escolha um arquivo novo para preservar o banco atual.');
const dump=readFileSync(input,'utf8');
mkdirSync(dirname(target),{recursive:true});
const temporary=mkdtempSync(join(dirname(target),'.alca-import-'));
const file=join(temporary,'import.sqlite');
try{
  const db=new DatabaseSync(file,{enableForeignKeyConstraints:false});
  try{
    db.exec(dump);
    const integrity=db.prepare('PRAGMA integrity_check').get().integrity_check;
    if(integrity!=='ok')throw Error('O banco importado falhou na verificação de integridade.');
    const players=db.prepare('SELECT COUNT(*) AS total FROM nexus_players').get().total;
    console.log('Contas encontradas no backup: '+players);
  }finally{db.close();}
  linkSync(file,target);
  console.log('Banco importado em '+target);
}finally{rmSync(temporary,{recursive:true,force:true});}
