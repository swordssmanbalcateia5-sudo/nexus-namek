import {createServer} from 'node:http';
import {createReadStream} from 'node:fs';
import {readFile,stat} from 'node:fs/promises';
import {isIP} from 'node:net';
import {dirname,extname,resolve,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {pipeline} from 'node:stream/promises';
import worker from '../public/_worker.js';
import {openDatabase} from './sqlite.js';

const source=dirname(fileURLToPath(import.meta.url));
const publicDir=resolve(source,'../public');
const host=process.env.ALCA_HOST||'127.0.0.1';
const port=Number(process.env.ALCA_PORT||4173);
if(!Number.isInteger(port)||port<=0||port>65535)throw Error('ALCA_PORT deve ser uma porta de 1 a 65535.');
const origin=new URL(process.env.ALCA_PUBLIC_URL||('http://127.0.0.1:'+port));
if(!['http:','https:'].includes(origin.protocol)||origin.pathname!=='/'||origin.search||origin.hash||origin.username||origin.password)
  throw Error('ALCA_PUBLIC_URL deve conter apenas o esquema e o domínio do jogo.');
const databasePath=resolve(process.env.ALCA_DB||resolve(source,'../data/alca.sqlite'));
if(databasePath===publicDir||databasePath.startsWith(publicDir+sep))throw Error('O arquivo SQLite deve ficar fora de public/.');
const db=openDatabase(databasePath);
const env={NEXUS_DB:db,
  GOOGLE_CLIENT_ID:process.env.GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET:process.env.GOOGLE_CLIENT_SECRET,
  DISCORD_CLIENT_ID:process.env.DISCORD_CLIENT_ID,
  DISCORD_CLIENT_SECRET:process.env.DISCORD_CLIENT_SECRET};
const defaultHeaderBlock=(await readFile(resolve(publicDir,'_headers'),'utf8'))
  .split(/\r?\n\//,1)[0].split(/\r?\n/).slice(1);
const securityHeaders=Object.fromEntries(defaultHeaderBlock.filter(line=>line.trim()).map(line=>{
    const index=line.indexOf(':');
    return [line.slice(0,index).trim(),line.slice(index+1).trim()];
  }));
const types={
  '.html':'text/html; charset=utf-8',
  '.js':'text/javascript; charset=utf-8',
  '.css':'text/css; charset=utf-8',
  '.webmanifest':'application/manifest+json',
  '.json':'application/json',
  '.png':'image/png',
  '.webp':'image/webp',
};
const bodyLimit=100*1024;

function respond(res,status,message){
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(JSON.stringify({error:message}));
}

async function api(req,res,url){
  const method=req.method;
  const headers=new Headers(req.headers);
  const socketIP=req.socket.remoteAddress;
  const proxyIP=req.headers['x-alca-client-ip'];
  const loopback=socketIP==='127.0.0.1'||socketIP==='::1'||socketIP==='::ffff:127.0.0.1';
  if(process.env.ALCA_TRUST_PROXY==='1'&&loopback&&typeof proxyIP==='string'&&isIP(proxyIP)){
    headers.set('CF-Connecting-IP',proxyIP);
  }else{
    headers.set('CF-Connecting-IP',socketIP||'local');
  }
  headers.delete('x-alca-client-ip');
  headers.delete('cf-ray');
  let body;
  if(method!=='GET'&&method!=='HEAD'){
    if(Number(req.headers['content-length'])>bodyLimit){req.resume();respond(res,413,'Pedido muito grande.');return;}
    const chunks=[];
    let size=0;
    for await(const chunk of req.iterator({destroyOnReturn:false})){
      size+=chunk.length;
      if(size>bodyLimit){req.resume();respond(res,413,'Pedido muito grande.');return;}
      chunks.push(chunk);
    }
    body=Buffer.concat(chunks,size);
  }
  const response=await worker.fetch(new Request(url,{method,headers,body}),env);
  for(const [name,value] of response.headers)if(name!=='set-cookie')res.setHeader(name,value);
  const cookies=response.headers.getSetCookie();
  if(cookies.length)res.setHeader('Set-Cookie',cookies);
  res.writeHead(response.status);
  res.end(method==='HEAD'?undefined:Buffer.from(await response.arrayBuffer()));
}

async function asset(req,res,url){
  if(req.method!=='GET'&&req.method!=='HEAD'){
    res.setHeader('Allow','GET, HEAD');
    respond(res,405,'Método indisponível para arquivos.');
    return;
  }
  let path;
  try{path=decodeURIComponent(url.pathname);}
  catch{respond(res,400,'Endereço inválido.');return;}
  if(path==='/')path='/index.html';
  const type=types[extname(path)];
  if(!type||path.split('/').some(part=>part.startsWith('_')||part.startsWith('.'))){
    respond(res,404,'Arquivo não encontrado.');return;
  }
  const file=resolve(publicDir,'.'+path);
  if(!file.startsWith(publicDir+sep)){respond(res,404,'Arquivo não encontrado.');return;}
  const info=await stat(file).catch(error=>{
    if(error.code==='ENOENT'||error.code==='ENOTDIR')return null;
    throw error;
  });
  if(!info?.isFile()){respond(res,404,'Arquivo não encontrado.');return;}
  res.writeHead(200,{...securityHeaders,'Content-Type':type,'Content-Length':info.size,
    'Cache-Control':path.startsWith('/art/')?'public, max-age=3600':'no-cache'});
  if(req.method==='HEAD'){res.end();return;}
  await pipeline(createReadStream(file),res);
}

const initialized=await worker.fetch(new Request(new URL('/api/discoveries',origin)),env);
if(!initialized.ok){db.close();throw Error('Falha ao inicializar a estrutura do banco Alca RNG.');}
const server=createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,origin);
    if(!req.url.startsWith('/')||url.origin!==origin.origin){
      respond(res,400,'Endereço inválido.');return;
    }
    if(url.pathname.startsWith('/api/'))await api(req,res,url);
    else await asset(req,res,url);
  }catch(error){
    if(req.destroyed||res.destroyed)return;
    console.error('Falha ao atender uma requisição do Alca RNG:',error.name);
    if(res.headersSent)res.destroy();
    else respond(res,500,'Não foi possível atender a requisição.');
  }
});
server.listen(port,host,()=>console.log('Alca RNG disponível em '+origin.origin+' (porta '+port+').'));
function stop(){server.close(()=>{db.close();});}
process.once('SIGINT',stop);
process.once('SIGTERM',stop);
