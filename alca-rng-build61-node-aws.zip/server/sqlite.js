import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {dirname} from 'node:path';

// The current Worker uses D1 prepared statements and atomic batches.
export function openDatabase(file){
  mkdirSync(dirname(file),{recursive:true});
  const db=new DatabaseSync(file);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
  function prepare(sql,values=[]){
    const statement=()=>db.prepare(sql);
    const all=(query=statement())=>({results:query.all(...values)});
    const run=(query=statement())=>{
      const {changes,lastInsertRowid}=query.run(...values);
      return {results:[],meta:{changes:Number(changes),last_row_id:Number(lastInsertRowid)}};
    };
    return {
      bind:(...params)=>prepare(sql,params),
      first:()=>statement().get(...values)??null,
      all,
      run,
      execute:()=>{
        const query=statement();
        return query.columns().length?all(query):run(query);
      }
    };
  }
  return {
    prepare,
    batch(statements){
      db.exec('BEGIN IMMEDIATE');
      try{
        const results=statements.map(statement=>statement.execute());
        db.exec('COMMIT');
        return results;
      }catch(error){
        db.exec('ROLLBACK');
        throw error;
      }
    },
    close:()=>db.close()
  };
}
