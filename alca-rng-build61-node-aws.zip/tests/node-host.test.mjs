import assert from 'node:assert/strict';
import {execFileSync,spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtemp,rm,writeFile} from 'node:fs/promises';
import {createServer} from 'node:net';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import test from 'node:test';

async function freePort(){
  const server=createServer();
  server.listen(0,'127.0.0.1');
  await once(server,'listening');
  const {port}=server.address();
  await new Promise(resolve=>server.close(resolve));
  return port;
}

async function start(database){
  const port=await freePort();
  const origin='http://127.0.0.1:'+port;
  const child=spawn(process.execPath,['server/index.js'],{
    env:{...process.env,ALCA_HOST:'127.0.0.1',ALCA_PORT:String(port),ALCA_DB:database,ALCA_PUBLIC_URL:origin,
      GOOGLE_CLIENT_ID:'test-client',GOOGLE_CLIENT_SECRET:'test-secret'},stdio:'pipe',
  });
  const closed=once(child,'exit');
  const stop=async()=>{child.kill();await closed;};
  try{
    for(let i=0;i<80;i++){
      if(child.exitCode!==null)throw Error('O servidor Node terminou antes do teste.');
      const health=await fetch(origin+'/api/health').catch(()=>null);
      if(health){
        assert.equal(health.status,200);
        assert.equal((await health.json()).build,'nexus-namek-61');
        return {origin,stop};
      }
      await new Promise(resolve=>setTimeout(resolve,30));
    }
    throw Error('O servidor Node não respondeu.');
  }catch(error){await stop();throw error;}
}

test('Node serve o jogo e conserva a conta ao importar e reabrir um SQLite',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'alca-node-'));
  let server;
  try{
    const initial=join(dir,'original.sqlite'),target=join(dir,'importado.sqlite');
    server=await start(initial);
    const post=(path,body,token)=>fetch(server.origin+path,{
      method:'POST',headers:{'Content-Type':'application/json',Origin:server.origin,...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(body),
    });
    assert.match(await (await fetch(server.origin)).text(),/<title>Alca RNG/);
    assert.equal((await fetch(server.origin+'/_worker.js')).status,404);
    assert.equal((await post('/api/game',{})).status,401);
    assert.equal((await post('/api/game',{overflow:'x'.repeat(110*1024)})).status,413);
    const registration=await post('/api/community/account',{name:'Teste Alca Node'});
    assert.equal(registration.status,201);
    const {token,player}=await registration.json();
    const session=await post('/api/game',{visible:true,checkpoints:true},token);
    assert.equal(session.status,200);
    assert.ok((await session.json()).state.pending);
    const oauth=await post('/api/auth/google/start',{intent:'login'});
    assert.equal(oauth.status,200);
    const redirect=new URL((await oauth.json()).url);
    assert.equal(redirect.searchParams.get('redirect_uri'),server.origin+'/api/auth/google/callback');
    assert.match(oauth.headers.get('set-cookie'),/Secure/);

    await server.stop();
    server=null;
    const database=new DatabaseSync(initial);
    const quote=value=>value===null?'NULL':typeof value==='number'?String(value):"'"+value.replaceAll("'","''")+"'";
    const schema=database.prepare('SELECT type,name,sql FROM sqlite_schema WHERE sql IS NOT NULL AND name NOT LIKE ? ORDER BY rowid').all('sqlite_%');
    const tables=schema.filter(r=>r.type==='table');
    const inserts=tables.flatMap(({name})=>database.prepare('SELECT * FROM "'+name+'"').all().map(row=>
      'INSERT INTO "'+name+'" VALUES ('+Object.values(row).map(quote).join(',')+');'));
    const dump=join(dir,'backup-d1.sql');
    await writeFile(dump,[...tables.map(r=>r.sql+';'),...inserts,...schema.filter(r=>r.type!=='table').map(r=>r.sql+';')].join('\n'));
    database.close();
    execFileSync(process.execPath,['server/import-d1.js',dump,target]);
    server=await start(target);
    const resumed=await post('/api/game',{visible:true,checkpoints:true},token);
    assert.equal(resumed.status,200);
    const resumedData=await resumed.json();
    assert.equal(resumedData.player.id,player.id);
    assert.equal(resumedData.state.collection.length,4);
  }finally{if(server)await server.stop();await rm(dir,{recursive:true,force:true});}
});
