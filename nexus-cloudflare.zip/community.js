import {CHARACTERS,COLORS,dailyRaidBoss,spriteFor} from './game.js';
import {DAILY_ZONE,GIFT_GOLD,PROFILE_OPTIONS,PROFILE_WORLDS,AVATAR_SIZE,rarityLabel} from './community-rules.js';

const tokenKey='nexus.community.access';
const number=new Intl.NumberFormat('pt-BR');
const date=new Intl.DateTimeFormat('pt-BR',{timeZone:DAILY_ZONE,dateStyle:'short',timeStyle:'short'});
const icons={estrela:'✦',cometa:'☄',escudo:'⬟'};
const escape=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
function savedToken(){try{return localStorage.getItem(tokenKey)||'';}catch{return '';}}
function duration(ms){
  const seconds=Math.max(0,Math.ceil(ms/1000));
  return [Math.floor(seconds/3600),Math.floor(seconds/60)%60,seconds%60].map(v=>String(v).padStart(2,'0')).join(':');
}
function playTime(ms){
  const minutes=Math.floor(ms/60000);
  return `${Math.floor(minutes/60)} h ${minutes%60} min`;
}
function odds(unit){
  return unit.odds?`<strong class="rarity-value" title="1 em ${number.format(unit.odds)}">${rarityLabel(unit.odds)}</strong>`:'';
}
const empty=text=>`<p class="community-empty">${text}</p>`;

async function squareAvatar(file){
  if(file.size>8*1024*1024)throw Error('Escolha uma foto de até 8 MB.');
  if(!['image/png','image/jpeg','image/webp','image/gif'].includes(file.type))throw Error('Escolha uma foto PNG, JPG, WebP ou GIF.');
  const url=URL.createObjectURL(file);
  try{
    const image=new Image();
    image.src=url;
    await image.decode();
    const side=Math.min(image.naturalWidth,image.naturalHeight);
    if(!side)throw Error('Imagem vazia.');
    const canvas=document.createElement('canvas');
    canvas.width=canvas.height=AVATAR_SIZE;
    const ctx=canvas.getContext('2d');
    ctx.imageSmoothingQuality='high';
    ctx.drawImage(image,(image.naturalWidth-side)/2,(image.naturalHeight-side)/2,side,side,0,0,AVATAR_SIZE,AVATAR_SIZE);
    return canvas.toDataURL('image/png');
  }catch{throw Error('Não foi possível abrir a foto. Tente outro arquivo.');}
  finally{URL.revokeObjectURL(url);}
}
const sceneAttrs=key=>Object.hasOwn(PROFILE_WORLDS,key)?`data-world="${PROFILE_WORLDS[key]}"`:'';
const emblem=appearance=>appearance.avatar?`<img src="${escape(appearance.avatar)}" alt="">`:icons[appearance.icon]??icons.estrela;

export function createCommunity({spriteURL,onSession,onChallenge}){
  const supported=location.protocol!=='file:';
  const root=document.querySelector('#community-panel');
  const dialog=document.querySelector('#player-profile');
  if(!root||!dialog)return null;
  const content=dialog.querySelector('.player-profile-content');
  const message=root.querySelector('.community-message');
  const body=root.querySelector('.community-content');
  let token=supported?savedToken():'';
  let me=null,section='rarity',profile=null,view='team',opener=null,profileRequest=0;
  let ranking=null,friends=null,clock=null,clockRefresh=false;
  let busy=false;
  let draft=null,photoJob=0,readingPhoto=false,saving=false;
  function updatePreview(){
    const banner=content.querySelector('.player-banner');
    if(!banner||!draft)return;
    banner.dataset.background=draft.background;
    banner.dataset.border=draft.border;
    if(Object.hasOwn(PROFILE_WORLDS,draft.background))banner.dataset.world=PROFILE_WORLDS[draft.background];
    else delete banner.dataset.world;
    banner.querySelector('.player-emblem').innerHTML=emblem(draft);
    const form=content.querySelector('[data-form="customize"]');
    if(!form)return;
    form.querySelector('[data-bg-label]').textContent=PROFILE_OPTIONS.background[draft.background];
    form.querySelector('[data-remove-photo]').hidden=!draft.avatar;
    form.elements.icon.disabled=!!draft.avatar;
    form.querySelector('[type="submit"]').disabled=readingPhoto||saving;
  }
  const showMessage=text=>{message.textContent=text;message.hidden=!text;};
  async function request(path,input,access=token){
    const response=await fetch('/api'+path,{
      method:input===undefined?'GET':'POST',
      headers:{...(access?{Authorization:'Bearer '+access}:{}),...(input===undefined?{}:{'Content-Type':'application/json'})},
      body:input===undefined?undefined:JSON.stringify(input),
      signal:AbortSignal.timeout(10000),
    });
    if(!response.headers.get('content-type')?.includes('application/json'))throw Error('A Comunidade precisa do servidor Nexus.');
    const data=await response.json();
    if(!response.ok){
      const error=new Error(data.error);
      error.status=response.status;
      throw error;
    }
    return data;
  }
  async function game(action,observationAge){
    const access=token;
    const data=await request('/game',{action,visible:!document.hidden,observationAge},access);
    if(access!==token)return null;
    me=data.player;
    return data;
  }
  function setToken(value){
    token=value;
    try{if(value)localStorage.setItem(tokenKey,value);else localStorage.removeItem(tokenKey);}catch{}
  }
  function clear(){
    me=null;ranking=null;friends=null;clock=null;section='rarity';
    setToken('');
    if(dialog.open)dialog.close();
    render();
  }
  async function signIn(access){
    const data=await request('/game',{visible:!document.hidden,observationAge:document.hidden?null:0},access);
    me=data.player;
    setToken(access);
    ranking=null;friends=null;
    onSession(data);
    render();
    await loadSection();
  }
  function avatar(unit){
    const {id,xp,shiny,trait,serial,odds}=unit;
    const data=escape(JSON.stringify({id,xp,shiny,trait,serial,odds}));
    const card=CHARACTERS[unit.id];
    return `<button class="unit-portrait" type="button" data-public-unit="${data}" aria-label="Ficha de ${escape(card.name)}"><img class="community-sprite" src="${spriteURL(spriteFor(unit))}" alt="" style="--unit-color:${COLORS[card.color]}"></button>`;
  }
  function namedPlayer(player){
    return `<button class="player-link" type="button" data-player="${escape(player.id)}">${escape(player.name)}</button>`;
  }
  function rankArt(){
    if(!ranking)return empty('Carregando classificação…');
    const list=ranking[section]??[];
    if(!list.length)return empty(section==='raid'?'Nenhum explorador atacou o Chefe do dia neste ciclo ainda.':'Os primeiros recrutas e jogadores aparecerão aqui conforme as expedições avançarem.');
    return `<ol class="rank-list">${list.map((row,i)=>section==='rarity'?`
      <li class="rank-row"><span class="rank-number">${i+1}</span>${avatar(row)}
        <div class="rank-description"><strong>${escape(row.name)}${row.shiny?' ✦':''}</strong><small>${row.trait?escape(row.trait)+' · ':''}#${String(row.serial).padStart(3,'0')} · ${namedPlayer(row.player)}</small></div>${odds(row)}</li>`:section==='raid'?`
      <li class="rank-row"><span class="rank-number">${i+1}</span><div class="top-team">${row.units.map(avatar).join('')}</div>
        <div class="rank-description">${namedPlayer(row.player)}<small>${row.units.map(u=>escape(u.name)).join(' · ')}</small></div><strong class="power-value">${number.format(row.damage)} dano</strong></li>`:`
      <li class="rank-row"><span class="rank-number">${i+1}</span><div class="top-team">${row.units.map(avatar).join('')}</div>
        <div class="rank-description">${namedPlayer(row.player)}<small>${row.units.map(u=>escape(u.name)).join(' · ')}</small></div><strong class="power-value">${number.format(row.power)}</strong></li>`).join('')}</ol>`;
  }
  function friendList(){
    if(!friends)return empty('Carregando amigos…');
    return `<form class="community-form friend-add" data-form="friend"><label for="friend-code">Código de amigo</label>
      <div class="inline-fields"><input id="friend-code" name="code" maxlength="10" required autocomplete="off" spellcheck="false" placeholder="10 caracteres">
      <button class="primary">Enviar convite</button></div></form>
      <h3>Amigos</h3>${friends.friends.length?`<ul class="friends-list">${friends.friends.map(row=>`<li>${namedPlayer(row)}
      <span class="friend-actions"><button class="ghost" data-gift="${row.id}" ${row.sent?'disabled':''}>${row.sent?'Presente enviado':'Presentear'}</button>
      <button class="ghost" data-remove="${row.id}" aria-label="Remover ${escape(row.name)}">Remover</button></span></li>`).join('')}</ul>`:empty('Adicione um amigo usando o código que aparece no perfil dele.')}
      <h3>Convites</h3>${friends.requests.length?`<ul class="friends-list">${friends.requests.map(row=>`<li>${namedPlayer(row)}
      <span class="friend-actions">${row.requested_by!==me?.id?`<button class="primary" data-accept="${row.id}">Aceitar</button>`:'<small>Convite enviado</small>'}
      <button class="ghost" data-remove="${row.id}">${row.requested_by===me?.id?'Cancelar':'Recusar'}</button></span></li>`).join('')}</ul>`:empty('Você está em dia com os convites.')}
      <h3>Presentes recebidos</h3>${friends.inbox.length?`<ul class="friends-list">${friends.inbox.map(row=>`<li><span>${namedPlayer(row)} <small>· ${date.format(row.sentAt)}</small></span><strong>+${number.format(row.gold)} ouro</strong></li>`).join('')}</ul>`:empty('O ouro dos presentes entra direto no saldo.')}
    `;
  }
  function render(){
    if(!supported){
      body.innerHTML=empty('Abra a versão servida pelo Nexus para jogar com outras contas. Este arquivo abre o jogo solo.');
      return;
    }
    if(!me){
      body.innerHTML=token?empty('Conectando à Comunidade…'):`<div class="community-auth">
        <form class="community-form card" data-form="register"><h3>Criar perfil</h3><p class="caption">A conta online começa uma nova expedição. Seu progresso solo fica neste navegador.</p>
        <label for="new-player">Nome do jogador</label><input id="new-player" name="name" minlength="2" maxlength="24" required autocomplete="nickname"><button class="primary">Criar perfil</button></form>
        <form class="community-form card" data-form="restore"><h3>Entrar</h3><p class="caption">Use o código de acesso privado do seu perfil para recuperar a conta.</p>
        <label for="access-code">Código de acesso</label><input id="access-code" name="access" required autocomplete="off" type="password"><button class="ghost">Entrar na conta</button></form>
        </div>`;
      return;
    }
    const raidBoss=ranking?.raidDay?dailyRaidBoss(ranking.raidDay):null;
    body.innerHTML=`<div class="community-toolbar"><nav class="community-tabs" aria-label="Comunidade">
      ${[['rarity','Raridade'],['power','Força'],['raid','Chefe do dia'],['friends','Amigos']].map(([id,label])=>`<button class="ghost" data-community-tab="${id}" aria-pressed="${id===section}">${label}</button>`).join('')}</nav>
      <div class="friend-actions"><button class="ghost" data-refresh>Atualizar</button><button class="ghost" data-my-profile>Meu perfil</button></div></div>
      <p class="caption community-help">${section==='rarity'?'Personagens recrutados ordenados pela chance de obtenção.':section==='power'?'Soma dos atributos dos quatro personagens mais fortes do inventário, com Shiny e Traits.':section==='raid'?(raidBoss?`Maior dano em 60 s contra ${escape(raidBoss.name)} (${escape(raidBoss.color)}) no ciclo ${escape(ranking.raidDay)}.`:'Maior dano em 60 s no Chefe do dia. Reset às 12h, horário de Brasília.'):'Um presente de '+number.format(friends?.giftGold??GIFT_GOLD)+' ouro por amigo a cada ciclo. Reset às 12h, horário de Brasília.'}</p>
      ${section==='friends'?'<p class="daily-clock">Próximo reset <strong data-reset-clock>—</strong></p>'+friendList():rankArt()}`;
    tick();
  }
  async function loadSection(){
    if(!me||root.hidden)return;
    const access=token;
    const wanted=section;
    if(wanted==='friends'){
      const data=await request('/community/friends');
      if(access!==token)return;
      friends=data;
      clock={start:performance.now(),remaining:data.cycle.nextAt-data.now};
    }else{
      const data=await request('/community/rankings');
      if(access!==token)return;
      ranking=data;
    }
    if(wanted===section)render();
  }
  async function guarded(work){
    if(busy)return;
    busy=true;
    showMessage('');
    try{await work();}
    catch(error){showMessage(error.message||'Não foi possível acessar a Comunidade.');}
    finally{busy=false;}
  }
  function tick(){
    if(root.hidden||section!=='friends'||!clock)return;
    const remaining=clock.remaining-(performance.now()-clock.start);
    const node=root.querySelector('[data-reset-clock]');
    if(node)node.textContent=duration(remaining);
    if(remaining<=0&&!clockRefresh){
      clockRefresh=true;
      void loadSection().catch(error=>showMessage(error.message)).finally(()=>{
        setTimeout(()=>{clockRefresh=false;},1500);
      });
    }
  }
  function showProfile(){
    const isMine=profile.id===me?.id;
    const attributes=isMine&&draft?draft:profile.appearance;
    const team=profile[view];
    content.innerHTML=`<header class="player-banner" data-background="${escape(attributes.background)}" ${sceneAttrs(attributes.background)} data-border="${escape(attributes.border)}">
      <span class="player-emblem" aria-hidden="true">${emblem(attributes)}</span><div><h2 id="player-profile-title">${escape(profile.name)}</h2>
      <p>Código de amigo <strong>${profile.code}</strong></p></div></header>
      <div class="player-meta"><div><span>Tempo de jogo ativo</span><strong>${playTime(profile.playMs)}</strong></div>
      <div><span>Encontros concluídos</span><strong>${number.format(profile.encounters)}</strong></div>${profile.raidBestEver?`<div><span>Recorde na Raid</span><strong>${number.format(profile.raidBestEver)} dano</strong></div>`:''}</div>
      <div class="community-tabs"><button class="ghost" data-view="team" aria-pressed="${view==='team'}">Time atual</button>
      <button class="ghost" data-view="showcase" aria-pressed="${view==='showcase'}">Destaques</button></div>
      ${view==='showcase'?'<p class="caption">Até cinco personagens com menor chance de obtenção.</p>':''}
      ${team.length?`<ul class="player-team">${team.map(unit=>`<li>${avatar(unit)}<div><strong>${escape(unit.name)}${unit.shiny?' ✦':''}</strong>
      <small>Nv. ${unit.level}${unit.trait?' · '+escape(unit.trait):''} · #${String(unit.serial).padStart(3,'0')}</small></div>${odds(unit)}</li>`).join('')}</ul>`:empty('As primeiras capturas aparecerão em Destaques.')}
      ${!isMine?'<button class="primary" data-challenge>Desafiar na Arena</button>':''}
      ${isMine?`<form class="community-form customize" data-form="customize"><h3>Personalizar perfil</h3>
      <fieldset class="appearance-fields" ${saving?'disabled':''}>
      <details class="scene-picker"><summary>Fundo · <span data-bg-label>${escape(PROFILE_OPTIONS.background[attributes.background])}</span></summary>
      <div class="scene-grid" role="radiogroup" aria-label="Fundo do perfil">${Object.entries(PROFILE_OPTIONS.background).map(([key,label])=>`<label class="scene-choice" data-background="${key}" ${sceneAttrs(key)}>
      <input type="radio" name="background" value="${key}" ${key===attributes.background?'checked':''}><span>${escape(label)}</span></label>`).join('')}</div></details>
      <div class="avatar-upload"><label>Foto de perfil<input type="file" data-photo accept="image/png,image/jpeg,image/webp,image/gif" aria-describedby="avatar-hint"></label>
      <button class="ghost" type="button" data-remove-photo ${attributes.avatar?'':'hidden'}>Remover foto</button></div>
      <small id="avatar-hint">PNG, JPG, WebP ou GIF de até 8 MB. O recorte é quadrado e central. GIFs ficam estáticos.</small>
      <div class="customize-inputs">${['icon','border'].map(key=>`<label>${key==='icon'?'Ícone padrão':'Borda'}
      <select name="${key}" ${key==='icon'&&attributes.avatar?'disabled':''}>${Object.entries(PROFILE_OPTIONS[key]).map(([value,label])=>`<option value="${value}" ${attributes[key]===value?'selected':''}>${label}</option>`).join('')}</select></label>`).join('')}
      </div><button class="primary" type="submit" ${readingPhoto||saving?'disabled':''}>Salvar aparência</button></fieldset></form>
      <details class="community-access"><summary>Código de acesso privado</summary><p class="caption">Guarde para entrar em outro navegador. Envie aos amigos somente o código de amigo.</p>
      <input class="access-code" readonly aria-label="Código de acesso privado" value="${escape(token)}"><button class="ghost" data-sign-out>Sair da conta</button></details>`:''}`;
  }
  async function openProfile(button,playerId){
    const requestId=++profileRequest;
    const data=await request('/community/profile'+(playerId?'/'+playerId:''));
    if(requestId!==profileRequest)return;
    profile=data;view='team';opener=button;
    draft=profile.id===me?.id?{...profile.appearance}:null;photoJob++;readingPhoto=false;saving=false;
    showProfile();
    if(!dialog.open)dialog.showModal();
  }
  root.addEventListener('click',event=>{
    const target=event.target.closest('button');
    if(!target)return;
    const d=target.dataset;
    const next=d.communityTab;
    if(next){
      section=next;render();void loadSection().catch(error=>showMessage(error.message));
    }else if('refresh' in d){
      void guarded(loadSection);
    }else if(d.player||'myProfile' in d){
      void guarded(()=>openProfile(target,d.player));
    }else if(d.gift||d.accept||d.remove){
      void guarded(async()=>{
        const input=d.gift?{id:d.gift}:{id:d.accept??d.remove,decision:d.accept?'accept':'remove'};
        await request(d.gift?'/community/gift':'/community/friend-reply',input);
        await loadSection();
        if(d.gift)showMessage('Presente entregue.');
      });
    }
  });
  root.addEventListener('submit',event=>{
    const form=event.target;
    const type=form.dataset.form;
    if(!type)return;
    event.preventDefault();
    const fields=Object.fromEntries(new FormData(form));
    void guarded(async()=>{
      if(type==='register'){
        const account=await request('/community/account',{name:fields.name},'');
        setToken(account.token);
        await signIn(account.token);
        await openProfile(root.querySelector('[data-my-profile]'));
        showMessage('Perfil criado. Guarde seu código de acesso privado.');
      }else if(type==='restore')await signIn(fields.access.trim());
      else if(type==='friend'){
        await request('/community/friend-request',{code:fields.code});
        await loadSection();
        showMessage('Convite enviado.');
      }
    });
  });
  dialog.addEventListener('change',async event=>{
    const input=event.target;
    if(!draft||!input.closest('[data-form="customize"]'))return;
    const status=dialog.querySelector('.player-status');
    if(input.hasAttribute('data-photo')){
      const file=input.files[0];
      if(!file)return;
      const job=++photoJob;
      readingPhoto=true;updatePreview();
      status.textContent='Preparando foto…';
      try{
        const result=await squareAvatar(file);
        if(job!==photoJob)return;
        draft.avatar=result;
        status.textContent='Confira a prévia e salve a aparência.';
      }catch(error){if(job===photoJob)status.textContent=error.message;}
      finally{if(job===photoJob){readingPhoto=false;input.value='';updatePreview();}}
    }else if(Object.hasOwn(PROFILE_OPTIONS,input.name)){
      draft[input.name]=input.value;
      updatePreview();status.textContent='Prévia · alterações por salvar.';
    }
  });
  dialog.addEventListener('click',event=>{
    const target=event.target.closest('button');
    if(!target)return;
    if(target.hasAttribute('data-remove-photo')&&draft){
      photoJob++;readingPhoto=false;draft.avatar=null;updatePreview();
      dialog.querySelector('.player-status').textContent='Ícone padrão na prévia. Salve para aplicar.';
      return;
    }
    if('challenge' in target.dataset && profile && profile.id!==me?.id){dialog.close();onChallenge(profile);return;}
    if(target.id==='close-player-profile')dialog.close();
    if(target.dataset.view){
      view=target.dataset.view;
      showProfile();
      content.querySelector(`[data-view="${view}"]`)?.focus();
    }
    if('signOut' in target.dataset){clear();onSession(null);}
  });
  dialog.addEventListener('submit',event=>{
    if(event.target.dataset.form!=='customize')return;
    event.preventDefault();
    if(!draft||readingPhoto||saving)return;
    const fields={...draft};
    if(fields.avatar===profile.appearance.avatar)delete fields.avatar;
    const requestId=profileRequest;
    const status=dialog.querySelector('.player-status');
    saving=true;event.target.querySelector('fieldset').disabled=true;status.textContent='Salvando…';
    void request('/community/profile',fields).then(data=>{
      if(!dialog.open||requestId!==profileRequest||profile?.id!==data.id)return;
      profile=data;draft={...data.appearance};
      status.textContent='Aparência salva.';
    }).catch(error=>{if(requestId===profileRequest)status.textContent=error.message;}).finally(()=>{
      if(requestId===profileRequest){saving=false;showProfile();}
    });
  });
  dialog.addEventListener('close',()=>{
    profileRequest++;photoJob++;draft=null;readingPhoto=false;saving=false;
    dialog.querySelector('.player-status').textContent='';
    if(opener?.isConnected)opener.focus();
    else root.querySelector('[data-my-profile]')?.focus();
  });

  return {
    active:()=>!!token,
    ready:()=>!!me,
    clear,game,tick,
    mount(){root.hidden=false;render();void loadSection().catch(error=>showMessage(error.message));},
    hide(){root.hidden=true;},
  };
}
